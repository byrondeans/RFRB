<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php



?>

<a href="index.php">Home</a>&nbsp;|&nbsp;<a href="links.php">Advice & Links</a>&nbsp;|&nbsp;Resume Advice<br /><br />

<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Resume / CV Advice</b></font>

<br /><br />

Your resume should always be custom tailored for each employer (mainly, your "objective" statement is what will 



reflect this.)  Never lie on your resume.  If possible, research the contact name of someone at the company, and 



address the cover letter to that person.<br /><br />



When listing responsibilities, always list your most important ones first, don't necessarily list them in the order of 



how much time you spent with them.  If possible, support your claims with facts that an employer can check: numbers 



are especially powerful, e.g. "reduced legal exposure by 50%."<br /><br />





Primacy effect: whatever is seen first is remembered best.<br /><br />



Employers like people who take good orders, but who are also self starters in the habit of taking action on their own.

  In your accomplishments, use action words like "spearheaded" and "launched" which give your resume a flavor of 



someone used to taking risks and implementing new ideas, instead of someone who merely proposes ideas.<br /><br />



In the objective section, tell how your strengths will help your future employer. 



For example "to get a job with a fast food restaurant chain as an upper manager" is not specific enough and does not 



explain what you will bring to the company.  Your objective should be no more than 3 lines, and should highlight what 



you plan to give to the company, not what you want to get from the company.  If you know what position you are 



seeking, it is good to mention that.<br /><br />



It's best to be specific with something like: bachelors of science in physics and electronics engineering with 



experience in computer programming seeks web building position with internet search company.



Be careful in the interests and hobbies section: you want to come off as being well-rounded and normal.



List education in reverse-chronological order (most recent first) and list your major, minor, School name and 



location, and possibly your gpa, if it is impressive for that school.<br /><br />



Make sure every word is meaningful.  Avoid boilerplate language that could be applied to your dog.<br /><br />



Always try to get at least two people to read your resume before sending it out.<br /><br />



You resume should highlight your ability as a worker: its about what you can and will do, not the responsibilities you 



once had.  Everything in the resume should point to this.<br /><br />





<br /><br />

<script type="text/javascript"><!--

google_ad_client = "pub-7032194388951945";

//468x60, created 12/13/07

google_ad_slot = "5615411376";

google_ad_width = 468;

google_ad_height = 60;

google_cpa_choice = ""; // on file

//--></script>

<script type="text/javascript"

src="http://pagead2.googlesyndication.com/pagead/show_ads.js">

</script>

<br /><br />



<script type="text/javascript"><!--

google_ad_client = "pub-7032194388951945";

//468x60, created 12/13/07

google_ad_slot = "5614670541";

google_ad_width = 468;

google_ad_height = 60;

google_cpa_choice = ""; // on file

//--></script>

<script type="text/javascript"

src="http://pagead2.googlesyndication.com/pagead/show_ads.js">

</script>

<br /><br />



<script type="text/javascript" language="javascript" src="http://www.kqzyfj.com/placeholder-2671856?



target=_blank&mouseover=Y"></script>
