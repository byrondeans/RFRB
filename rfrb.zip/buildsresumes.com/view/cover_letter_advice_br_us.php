<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php



?>

<a href="index.php">Home</a>&nbsp;|&nbsp;<a href="links.php">Advice & Links</a>&nbsp;|&nbsp;Cover Letter Advice<br /><br />

<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Cover Letter Advice</b></font>





A cover letter should be in this format:<br /><br />



your name and address<br /><br />



contact's name and address<br /><br />



1st Paragraph: who you are.  Your relationship with the person you are contacting or where you heard about the position you are applying for.  Also, it's best to include knowledge of the company and job you are applying for (the more you impress them with this knowledge, the better.)

<br /><br />

2nd Paragraph:  Tell them why you would be an ideal candidate for the job you are applying for.  If necessary,

tell them about your resume to elucidate what might otherwise be misunderstood.  Clearly describe the jobs you

are applying for to make it clear 

that you understand what the jobs are.

<br /><br />

3rd Paragraph:  Optional.  More elaboration of the second paragraph.<br /><br />



4th (final) Paragraph:  Your goodbye remarks.  It's good to mention how and when you will contact the person.

<br /><br />





<a href="http://www.jdoqocy.com/click-2727750-5683366" target="_blank" 



onmouseover="window.status='http://www.essayedge.com';return true;" onmouseout="window.status=' ';return true;">Sample 



Essays</a>

<img src="http://www.ftjcfx.com/image-2727750-5683366" width="1" height="1" border="0"/>



<br /><br />

<script type="text/javascript"><!--

google_ad_client = "pub-7032194388951945";

//468x60, created 12/13/07

google_ad_slot = "4786797858";

google_ad_width = 468;

google_ad_height = 60;

google_cpa_choice = ""; // on file

//--></script>

<script type="text/javascript"

src="http://pagead2.googlesyndication.com/pagead/show_ads.js">

</script>
