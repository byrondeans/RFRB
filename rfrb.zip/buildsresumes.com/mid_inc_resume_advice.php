<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php require("../buildsresumes.com/view/mid_google_ads.php"); 















?>

<h3>Sample Resumes</h3>

<a href="http://jobstar.org/tools/resume/samples.php">Jobstar Sample Resumes</a>

<br />



<h3>Cover Letter Writers</h3>

It is recommended to have a professional write (or at least edit) one's cover letter.<br />

<script type="text/javascript"><!--

google_ad_client = "pub-7032194388951945";

google_ad_width = 468;

google_ad_height = 60;

google_ad_format = "468x60_as";

google_cpa_choice = "CAEQmMimkQQQgMKSkgQaCHZbcQgB_j5OKKSQ4-sBKKSQ4-sB";

//-->

</script>

<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js">

</script>



<br />

<h3>Resume Writing Advice</h3>

<a href="http://www.careerperfect.com/content/resume-writing-help/">CareerPerfect.com's Resume Advice Section</a>
