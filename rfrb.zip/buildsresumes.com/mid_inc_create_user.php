<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php



/*assume this means that submit was clicked */

//*******************************

//*******************************

//*******************************SECTION1: VERIFY USERNAME and PASSWORD

//*******************************

if (isset($_POST['password1']))

{



/*

	if (file_exists($_POST['email1'].".txt"))

	die ("User already exists");

	

	$new_account_file = fopen ($_POST['email1'].".txt", "w");

*/



	$string_for_new_account = "";



		foreach ($_POST as $key => $i) {

			$string_for_new_account .= $key . "===" . $i . ";;;";

		}

//$con -= mysql_connect("localhost", "bdeans10_GO108", "jfitzgerald");		

/*$con -= mysql_connect("localhost", "root", "");*/

    //OLD require("database_access.php");

    $mysqli = new mysqli("localhost", "bdeans10_GO108", "jfitzgerald", "bdeans10_users");

	//OLD mysql_select_db("bdeans10_users",$con);





	$screen_name = $_POST['username'];

	if($screen_name == "")

	die("Username field cannot be empty.");



	//OLD $result = mysql_query ("SELECT info, screen_name FROM users WHERE screen_name='$screen_name'");

    $query = "SELECT info, screen_name FROM users WHERE screen_name='$screen_name'";

    $result = mysqli_query($mysqli, $query);



	$check = "";

	/*check if username exists.  If it does, signal error.*/

	//OLD while ($i = mysql_fetch_array($result)) { mysqli_fetch_assoc($res)

    while ($i = mysqli_fetch_assoc($result)) {

        $check = $i['screen_name'];

		if ($check == "")

		echo "Unique screen name: proceeding. <br />";



		if ($check != "")

		die ("The username " . $_POST['username'] . " already exists.  Please choose another.");

	}

//*******************************

//*******************************

//*******************************SECTION2: WRITE USER DATA TO DATABASE

//*******************************



$session_string = '';

foreach ($_SESSION as $key => $j) {

	$session_string .= $key . "===" . $i . ";;;";

}







	//ASSUME THE SCREEN NAME IS UNIQUE and ADD APPROPRIATE STRING

	//$screen_name = $_POST['email1'];

	//$date_added = date("d-m-Y");

	//$phone = $_POST['phone'];

	//$zip_postal = $_POST['postal_code'];

	//OLD mysql_query("INSERT INTO users (screen_name, info, session) VALUES('$screen_name', '$string_for_new_account', '$session_string' ) ") 

//OLD or die(mysql_error());  

    $query = "INSERT INTO users (screen_name, info, session) VALUES('$screen_name', '$string_for_new_account', '$session_string' ) ";

    mysqli_query($mysqli, $query);



/*

	fwrite ($new_account_file, $string_for_new_account);

*/









	/*write all data in $_POST to file SQL database */

/*	$check_email = mysql_query("SELECT email FROM users WHERE email=\"\'".$_POST['email1']."'");

	$check_email_array = mysql_fetch_array($check_email);

*/	

	

//*******************************

//*******************************

//*******************************SECTION3: WRITE USER SESSION FILE TO TEXT FILE

//*******************************

	

	/*create storage of session data for new account */

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	/*THE OLD WAY USING TEXT FILES 

	if (file_exists($_POST['email1']."-SESSION.txt"))

	die ("SESSION file already exists for this email.  Terminating.");

	

	$new_account_session_file = fopen ($_POST['email1']."-SESSION.txt", "w");

	$string_for_new_session_txt = "";

	foreach ($_SESSION as $key => $i) {

		$string_for_new_session_txt .= $key . "===" . $i . ";;;";

		}

	fwrite ($new_account_session_file, $string_for_new_session_txt);

	*/



	/*set sesssion to know user is logged in */

	$_SESSION['logged_in'] = 1;

	$_SESSION['screen_name'] = $_POST['username'];

	$_SESSION['password'] = $_POST['password1'];

	require("../buildsresumes.com/view/mid_google_ads.php");

	echo "Your new account has been created and your resume has been saved.  <a href=\"build_resume.php\">Continue.</a> <br /><br /><br /><br />";

	exit;

}



require("../buildsresumes.com/view/mid_google_ads.php");

?>

<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>

<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />







Enter your personal information:

<form action="create_user.php" method="post">

<table width="600" border="0">

  <tr>

    <td>First Name:&nbsp;</td>

    <td><span id="sprytextfield1">

      <input name="first_name" type="text" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

  </tr>

  <tr>

    <td>Last Name:&nbsp;</td>

    <td><span id="sprytextfield7">

      <input name="last_name" type="text" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

  </tr>

  <tr>

    <td>Address Line 1:&nbsp;</td>

    <td><span id="sprytextfield8">

      <input name="address_line_1" type="text" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

  </tr>

  <tr>

    <td>Address Line 2:&nbsp;</td>

    <td><input name="address_line_2" type="text" />&nbsp;</td>

  </tr>

  <tr>

    <td>City:&nbsp;</td>

    <td><span id="sprytextfield11">

<input name="city" type="text" />

<span class="textfieldRequiredMsg">A value is required.</span></span>&nbsp;</td>

  </tr>

  <tr>

    <td>Province/State/County:&nbsp;</td>

    <td><span id="sprytextfield12">

<input name="state" type="text" />

<span class="textfieldRequiredMsg">A value is required.</span></span>&nbsp;</td>

  </tr>

  <tr>

    <td>Postal Code: &nbsp;</td>

    <td><span id="sprytextfield13">

<input name="postal_code" type="text" />

<span class="textfieldRequiredMsg">A value is required.</span></span>&nbsp;</td>

  </tr>

  <tr>

    <td>Country:  &nbsp;</td>

    <td><span id="sprytextfield4">

<input name="country" type="text" />

<span class="textfieldRequiredMsg">A value is required.</span></span>&nbsp;</td>

  </tr>

  <tr>

    <td>Email Address&nbsp;</td>

    <td><span id="sprytextfield5">

<input name="email1" type="text" />

<span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.</span></span>&nbsp;</td>

  </tr>

  <tr>

    <td>Email Address (re-enter):&nbsp;</td>

    <td><span id="sprytextfield6">

<input name="email2" type="text" />

<span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.</span></span>&nbsp;</td>

  </tr>

  <tr>

    <td>Phone: &nbsp;</td>

    <td><span id="sprytextfield10">

    <label>

    <input type="text" name="phone" id="phone" />

    </label>

    <span class="textfieldRequiredMsg">A value is required.</span></span>&nbsp;    </td>

  </tr>

  <tr>

    <td>Username:&nbsp;</td>

    <td><span id="sprytextfield2">

      <input name="username" type="text" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

  </tr>

  <tr>

    <td>Password:&nbsp;</td>

    <td><span id="sprytextfield2">

      <input name="password1" type="password" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

  </tr>

  <tr>

    <td>Password (re-enter):&nbsp;</td>

    	<td><span id="sprytextfield3">

    	  <input name="password2" type="password" />

   	    <span class="textfieldRequiredMsg">A value is required.</span></span></td>

  </tr>

</table>



<br />

<br />

Check to receive special offers that might interest you from <?php echo $_SERVER['HTTP_HOST'] ?> and affiliated third parties: <br /> <input name="offers" type="checkbox" value="1" /> <br /><br />

<input type="submit" value="Create Account" />



</form>



<script type="text/javascript">

<!--

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");

var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");

var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");

var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");

var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "email");

var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6", "email");

var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");

var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");

var sprytextfield10 = new Spry.Widget.ValidationTextField("sprytextfield10", "none");

var sprytextfield11 = new Spry.Widget.ValidationTextField("sprytextfield11");

var sprytextfield12 = new Spry.Widget.ValidationTextField("sprytextfield12");

var sprytextfield13= new Spry.Widget.ValidationTextField("sprytextfield13");





//-->

</script>

