<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<a href="http://www.reallyfreeresumebuilder.com/advice_and_links.php">Back to Advice & Links</a>

<br /><br /><br /><br />



<P CLASS="western" STYLE="margin-bottom: 0in"><B>How to Write a Cover Letter:</B></P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">A cover letter is sent

in front of a resume, or sometimes by itself.  If sent with a resume,

it is supposed to help convince the reader that you'll be good at the

job for which you're applying.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">The first thing you

need to know about cover letters is that the reader will likely not

read the entire letter.  The reader will skim the letter, and if it

looks promising, give it another pass that will last from 30 to 60

seconds.  Your first job in writing a cover letter is to get the

reader to give your letter a second glance.  You do this by catching

the reader's attention in the first sentence.  Needless to say, your

first sentence must be unique, and set yours apart from other cover

letters.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Another important thing

to remember is that employers will almost never call you back because

of a cover letter.  You must initiate the call: in your cover letter,

specify a time when you will call, and follow up.  You may need to

call back 3 to 7 times before you get through to the person who has

the power to hire you.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Always address your

cover letter by name and title, if possible.  Sending out scores of

identical cover letters is ineffective.  It is important to address

the needs of the employer in your cover letter, and how you will help

with those needs.  In other words, it should be targeted.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Typically, a cover

letter will have 2&ndash;4 paragraphs.  It is not advisable to

include a P.S, which will most likely be read, but to some extent

signifies laziness and lack of thoroughness on the part of the

writer.  The paragraphs should generally be under 5 lines.  Since the

reader will not spend much time with your letter, it is important to

keep it simple and only include a couple of points, rather than

complex ideas.  To make the cover letter easier to read, try to keep

the length of your sentences under 25 words.  The cover letter should

fit on one page.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">The cover letter is a

form of advertising, and should comply with the basic principles of

effective advertising listed below:</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* Grab the attention of

the audience</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* Supply basic

information about the product or service and persuade that it's

useful/desirable</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* Back up your claims

with more information and examples</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* Make a call to action</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">For example, you might

start out by telling the reader that you're an admirer of his.

Explain that you know about his accomplishments, and why you admire

them (only if it's true).  You could then explain who you are, and

include information about what you can do for the employer.  Third,

you could selectively describe your achievements so as to back up the

second paragraph.  Finally, inform the person what time you'll be

calling.  This will serve as a call to action, causing them to

remember you and expect your call.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">In addition to being

professional, it's good to be personal in your cover letter so that

the reader likes you.  A friendly voice, combined with humor, will

break the ice nicely.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">After you've gotten

through and had a phone conversation, it's good to send a thank you

letter for the time spent (it's also a must to send a thank you

letter after a formal interview.)  Authors agree that thank you

letters are important in the job search as they make people like and

remember you.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">You will need to evaluate by what

medium the cover letter should be sent.  In some cases, you may diverge from

paper or email, and send a cover letter through a social network or other

site: there is 

no fixed rule.  The cover letter

should, if it is sent in the mail, be typed on high quality, thick

paper (a 20-pound bond is good) in a white or off-white color.  If it

is mailed on its own, it can be sent in a number 10 envelope of

matching color, and if sent with a resume, it should be sent in a

9x12 inch envelope.  The 9x12 envelope does not need to match the

paper.  It can be sent by express couriers, but if sent by standard

speed mail, it is best to use a pleasing commemorative stamp rather

than a standard issue.  It is best to laser-print the

address on the envelope, but a hand-written address is also

acceptable.  The address should not be printed on a label and

adhered.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">If sent in an email, do

not include the cover letter as an attachment; instead, include it in

the body of the email.  You can include the resume as an attachment.

It might be good to put the job you're applying for in the title of

the email.  Follow the usual cover letter rules for the email

cover letter where applicable.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">In sending out a cover

letter it's best to know whom you're sending it to by name and title,

and at least a little bit about the organization and the job that is

required.  To get this, you'll need to do some calling or research in

advance.  A cover letter should be unique so don't use &ldquo;canned&rdquo;

form letters: employers supposedly have a sixth sense for this kind

of thing.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">One way to research a

name and title is to call the company and ask the secretary.  Another

is to use the kind of letter that requests job information from

someone (also grouped with cover letters, and basically using similar

techniques).  You will simply write and ask if the contact knows of

any leads.  You will also want to address this type of letter to the

person by name, and title, and call at the specified time in your

letter.  You should never include a resume with this type of inquiry.

 By sending these job inquiry letters, you will uncover a huge

&ldquo;hidden&rdquo; list of unadvertised jobs that you can then

apply for by sending cover letters along with resumes to the

appropriate contacts.  These letters will hopefully get you on the

phone with the right person.  Again, after the person takes your call

and talks to you, it's good to write yet another letter thanking him

or her for his or her time.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">If you don't know whom

you're addressing, never use &ldquo;To Whom It May Concern&rdquo;.

Instead, write &ldquo;Dear Sir or Madam&rdquo;.  Use a colon after

the  &ldquo;Dear ____:&rdquo; instead of a comma.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">The only place you

should write on the letter is where you sign your signature.  Use a

fountain pen to sign the signature.  Blue ink is best next to the

black or near-black text.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">In summary, always pay

close attention to the appearance of the letter and envelope, grab

the reader's attention, and follow up with a phone call.</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Cover Letter Checklist:</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*2-4 paragraphs</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Pithy sentences</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Grab the reader's

attention in first line</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Describes why you'll

be useful (usually in the second paragraph)</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Supports your claims

with evidence (usually in the third paragraph)</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Specifies a time when

you'll call</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Signed with a fountain

pen</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Commemorative stamp

(if sent by post)</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*High-quality paper</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Bonus:</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*Demonstrate

understanding of reader</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">The four basic resume

formats are as follows:</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Block</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - Address - - -

- - - - - -</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - Address - - -

- - - - - -</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - Date  - - - -

- - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * * * Name  * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*  Title (very

important)* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* *  Company * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Dear Name:</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - - - - - - - -

- - - - - - - - - - - - - - - - - - - - - - - -   - - - - - - - - - -

 - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - -

- - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - -

- - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - -

- -  - - - - - - - - - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Square - Blocked</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - Address - - -

- - - - - -</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - Address - - -

- - - - - -</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in">- - - - -

Date  - - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * * * Name  * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*  Title (very

important)* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* *  Company * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Dear Name:</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - - - - - - - -

- - - - - - - - - - - - - - - - - - - - - - - -   - - - - - - - - - -

 - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - -

- - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - -

- - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - -

- -  - - - - - - - - - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Modified-Blocked</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in">- - - - -

Address - - - - - - - - -</P>

<P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in">- - - - -

Address - - - - - - - - -</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in">- - - - - -

Date  - - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * * * Name  * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*  Title (very

important)* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* *  Company * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Dear Name:</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">- - - - - - - - - - - -

- - - - - - - - - - - - - - - - - - - - - - - -   - - - - - - - - - -

 - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - -

- - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - -

- - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - -

- -  - - - - - - - - - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Semi-Blocked</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in">- - - - -

Address - - - - - - - - -</P>

<P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in">- - - - -

Address - - - - - - - - -</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in">- - - - - -

Date  - - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * * * Name  * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">*  Title (very

important)* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* *  Company * * * * *

* * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in">* * *  Address * * * *

* * * *</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">Dear Name:</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">&nbsp;     - - - - - - - - -

- - - - - - - - - - - - - - - - - - - - - - - - - - -   - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - -

-

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> &nbsp;    - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - -

- - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - -

- - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - -

- -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"> &nbsp;    - - - - - - - - -

-  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - -

- - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - -

- - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - -

- -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  -

- - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - -

- - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - -

- - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -

- - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - -

- - - - - - -  - - - - - - - - - -  - - - - - - - - - -  - - - - - -

- - - -  - - - - - - - - - -  - - - - - - - - - -

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in">(note the indentations)</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<P CLASS="western" STYLE="margin-bottom: 0in"><BR>

</P>

<?php require("../buildsresumes.com/view/mid_google_ads_cover_letter.php");





?>
