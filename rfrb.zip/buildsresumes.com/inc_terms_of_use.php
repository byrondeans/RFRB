<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php 

require("model/prices.php");

echo "<p>PLEASE READ THE FOLLOWING TERMS AND CONDITIONS (T &amp; C'S) RELATING TO YOUR USE OF OUR WEB SITE AND OUR FEE-BASED PRODUCTS CAREFULLY. By using our web site (&quot;" . $_SERVER['HTTP_HOST'] . "&quot;) you agree to the terms and conditions set forth in this Terms and Conditions of use agreement &quot;this Agreement&quot;). We reserve the right, in our sole discretion, to change, modify, add, or remove provisions of this Agreement at any time. You should check this Agreement periodically for changes. By using this web site after we post any changes to this Agreement, or otherwise notify you of such changes, you agree to accept those changes, whether or not you have reviewed them. If you do not agree to this Agreement, you should not use our web site and you should arrange to cancel your registered user account by emailing deans_ab@yahoo.com.<br>

  This Agreement is entered into by and between A.B. Deans Consulting and any individual, corporation, association, agency, company, or other entity accessing or using " . $_SERVER['HTTP_HOST'] . ".<br>

</p>

<p> 1. SCOPE OF AGREEMENT<br>

  Unless we indicate otherwise, this Agreement applies to your use of the web sites which are owned, operated, or powered by A.B. Deans Consulting (&quot;" . $_SERVER['HTTP_HOST'] . "&quot;, &quot;we,&quot; &quot;us,&quot; or &quot;our&quot;) and our affiliates, including, without limitation, this web site and any other web site that we may own, operate, or power currently or in the future, and all of the fee-based products that we may offer currently or in the future.<br>

  In consideration of your use of the service, you agree to: (a) provide true, accurate, current and complete information about yourself on all forms (eg. the Build Resume section and the Create Account page.) If you provide any information that is untrue, inaccurate, not current or incomplete, or A.B. Deans Consulting has reasonable grounds to suspect that such information is untrue, inaccurate, not current or incomplete, A.B. Deans Consulting has the right to suspend or terminate your account and refuse any and all current or future use of the service (or any portion thereof).<br>

</p>

<p>2. MEMBERS CONDUCT<br />

You agree to access and use " . $_SERVER['HTTP_HOST'] . " only for lawful purposes. You are solely responsible for the knowledge of and adherence to any and all laws, statutes, rules and regulations, pertaining to (i) use of " . $_SERVER['HTTP_HOST'] . ", including any interactive area, (ii) the use of any networks or other services connected to " . $_SERVER['HTTP_HOST'] . ", and (iii) the communications means by which they connect their modem, computer, or other equipment to " . $_SERVER['HTTP_HOST'] . ". By accessing " . $_SERVER['HTTP_HOST'] . ", you agree that you will not:<br>

  * Restrict or inhibit any other user from using and enjoying the service;<br>

  * Use " . $_SERVER['HTTP_HOST'] . " to send sales messages or to canvass users of the site in any way. (We reserve the right to terminate the access to " . $_SERVER['HTTP_HOST'] . " of any one found to be using " . $_SERVER['HTTP_HOST'] . " to advertise or canvass users, without express permission from  " . $_SERVER['HTTP_HOST'] . " and A.B. Deans Consulting.)<br>

  * Post or transmit any unlawful, threatening, abusive, libelous, defamatory, obscene, vulgar, pornographic, profane, or indecent information of any kind, including without limitation any transmissions constituting or encouraging conduct that would constitute a criminal offence, give rise to civil liability or otherwise violate any local, state, national, or international law;<br>

  * Post or transmit any information, software, or other material which violates or infringes in the rights of others, including material which is an invasion of privacy or publicity rights or which is protected by copyright, trademark or other proprietary right, or derivative works with respect thereto, without first obtaining permission from the owner or right holder;<br>

  * Post or transmit any information, software or other material which contains a virus or other harmful component;<br>

  * Alter, damage or delete any content or other communications that are not their own content or to otherwise interfere with the ability of others to access the site;<br>

  * Disrupt the normal flow of communication in any interactive area of the site;<br>

  * Claim a relationship with or to speak for any business, association, institution or other organization for which they are not authorised to claim such a relationship;<br>

  * Violate any operating rule, policy or guideline of their Internet access provider or online service.<br>

  Registration Data and certain other information about you are subject to our Privacy Policy.<br>

</p>

<p>3. MEMBER ACCOUNT, PASSWORD AND SECURITY<br>

  You will be asked to provide your own choice of username and password during completion of the Create Account process. You are responsible for maintaining the confidentiality of the password and account, and are fully responsible for all activities that occur under your password or account. You agree to (a) immediately notify " . $_SERVER['HTTP_HOST'] . " of any unauthorized use of your password or account or any other breach of security by emailing deans_ab@yahoo.com with the details of any unauthorized use of your password or account or any other breach of security, and (b) you agree not to access the web site by any means other than through the interface that is provided by " . $_SERVER['HTTP_HOST'] . ".  " . $_SERVER['HTTP_HOST'] . " cannot and will not be liable for any loss or damage arising from your failure to comply with this Section.<br>

<br>

</p>

<p>4. INDEMNIFICATION<br>

  <br>

  You agree to indemnify, hold harmless and, at our option, defend us and our affiliates, and our and their officers, directors, employees, stockholders, agents, and representatives from any and all third party claims, liability, damages, and/or costs (including, but not limited to, reasonable attorney's fees and expenses) arising from your improper use of this web site or our products or offerings, your violation of this Agreement, or your infringement, or the infringement or use by any other user of your account, of any intellectual property or other right of any person or entity.<br>

  <br>

</p>

<p>5. NO RESALE OF SERVICE<br>

  You agree not to reproduce, duplicate, copy, sell, resell or exploit for any commercial purposes, any portion of " . $_SERVER['HTTP_HOST'] . ", use of " . $_SERVER['HTTP_HOST'] . ", or access to " . $_SERVER['HTTP_HOST'] . ".  This includes any contact information or other information purchased or obtained from " . $_SERVER['HTTP_HOST'] . ".<br>

<br>

</p>

<p>6. MODIFICATIONS TO SERVICE<br>

  A.B. Deans Consulting reserves the right at any time and from time to time to modify or discontinue, temporarily or permanently, " . $_SERVER['HTTP_HOST'] . " (or any part thereof) with or without notice. You agree that A.B. Deans Consulting shall not be liable to you or to any third party for any modification, suspension or discontinuance of " . $_SERVER['HTTP_HOST'] . ".<br>

</p>

<p>7. TERMINATION<br>

  You agree that " . $_SERVER['HTTP_HOST'] . ", in its sole discretion, may terminate your password, account (or any part thereof) or use of " . $_SERVER['HTTP_HOST'] . ", and remove and discard any Content within " . $_SERVER['HTTP_HOST'] . ", for any reason, including, without limitation, for lack of use or if " . $_SERVER['HTTP_HOST'] . " believes that you have violated or acted inconsistently with the letter or spirit of the T &amp; C'S. A.B. Deans Consulting may also in its sole discretion and at any time discontinue providing " . $_SERVER['HTTP_HOST'] . ", or any part thereof, with or without notice. You agree that any termination of your access to " . $_SERVER['HTTP_HOST'] . " under any provision of these T &amp; C'S may be effected without prior notice, and acknowledge and agree that " . $_SERVER['HTTP_HOST'] . " may immediately deactivate or delete your account and all related information and files in your account and/or bar any further access to such files or " . $_SERVER['HTTP_HOST'] . ". Further, you agree that A.B. Deans Consulting or any of its officers, directors, employees, stockholders, agents, and representatives shall not be liable to you or any third-party for any termination of your access to " . $_SERVER['HTTP_HOST'] . ". The only right with respect to dissatisfaction with any policy, guideline, or practice of " . $_SERVER['HTTP_HOST'] . " or A.B. Deans Consulting, or any change in content, is for you to discontinue accessing the service. To request cancellation the member is required to email your username and password and a message stating that you wish your account to be terminated to deans_ab@yahoo.com. If any of these details are missing, your cancellation request will be ignored. Allow 5 - 10 working days for any cancellation request to be processed.<br>

<br>

</p>

<p>8. COMMUNICATIONS AND DEALINGS WITH SUPPLIERS<br>

  Your correspondence or business dealings with, or participation in promotions of, suppliers found on this site or through the Service, including payment and delivery of related goods or services, and any other terms, conditions, warranties or representations associated with such dealings, are solely between you and such supplier. You agree that " . $_SERVER['HTTP_HOST'] . " shall not be responsible or liable for any loss or damage of any sort incurred as the result of any such dealings or as the result of the presence of such suppliers on the Service.<br>

<br>

9. LINKS<br>

" . $_SERVER['HTTP_HOST'] . " may provide, or third parties may provide, links to other World Wide Web sites or resources. Because " . $_SERVER['HTTP_HOST'] . " has no control over such sites and resources, you acknowledge and agree that " . $_SERVER['HTTP_HOST'] . " is not responsible for the availability of such external sites or resources, and does not endorse and is not responsible or liable for any content, advertising, products, or other materials on or available from such sites or resources. You further acknowledge and agree that " . $_SERVER['HTTP_HOST'] . " shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such site or resource.<br>

</p>

<p>10. PROPRIETARY RIGHTS<br>

  You acknowledge and agree that the Service and any necessary software used in connection with the Service (&quot;Software&quot;) contain proprietary and confidential information that is protected by applicable intellectual property and other laws. You further acknowledge and agree that Content contained in sponsor advertisements or information presented to you through the Service or advertisers is protected by copyrights, trademarks, service marks, patents or other proprietary rights and laws. Except as expressly authorised by " . $_SERVER['HTTP_HOST'] . " or advertisers, you agree not to modify, rent, lease, loan, sell, distribute or create derivative works based on the Service , in whole or in part.<br>

<br>

</p>

<p>11. DISCLAIMER OF WARRANTIES<br>

</p>

<p>YOU EXPRESSLY UNDERSTAND AND AGREE THAT:<br>

a - YOUR USE OF THE SERVICE IS AT YOUR SOLE RISK. THE SERVICE IS PROVIDED ON AN &quot;AS IS&quot; AND &quot;AS AVAILABLE&quot; BASIS. " . $_SERVER['HTTP_HOST'] . " EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANDISE, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.<br>

</p>

<p>b - " . $_SERVER['HTTP_HOST'] . " MAKES NO WARRANTY THAT<br>

</p>

<p>(i) THE SERVICE WILL MEET YOUR REQUIREMENTS,<br>

  (ii) THE SERVICE WILL BE UNINTERRUPTED, TIMELY, SECURE, OR ERROR-FREE,<br>

  (iii) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SERVICE WILL BE ACCURATE OR RELIABLE,<br>

(iv) THE QUALITY OF ANY PRODUCTS, SERVICES, INFORMATION, OR OTHER MATERIAL PURCHASED OR OBTAINED BY YOUTHROUGH THE SERVICE WILL MEET YOUR EXPECTATIONS, AND<br>

(v) ANY ERRORS IN THE WEBSITE WILL BE CORRECTED. REFUNDS WILL THEREFORE ONLY BE GIVEN AT THE DISCRETION OF THE COMPANY MANAGEMENT.<br>

</p>

<p>c - ANY MATERIAL DOWNLOADED OR OTHERWISE OBTAINED THROUGH THE USE OF THE SERVICE IS DONE AT YOUR OWN DISCRETION AND RISK AND THAT YOU WILL BE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY SUCH MATERIAL.<br>

</p>

<p>d - NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM " . $_SERVER['HTTP_HOST'] . " OR THROUGH OR FROM THE SERVICE SHALL CREATE ANY WARRANTY NOT EXPRESSLY STATED IN THE T &amp; C'S. <br>

  LIMITATION OF LIABILITY<br>

  YOU UNDERSTAND AND AGREE THAT " . $_SERVER['HTTP_HOST'] . " SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL OR EXEMPLARY DAMAGES, INCLUDING BUT NOT LIMITED TO, DAMAGES FOR LOSS OF PROFITS, GOODWILL, USE, DATA OR OTHER INTANGIBLE LOSSES (EVEN IF " . $_SERVER['HTTP_HOST'] . " HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES), RESULTING FROM:<br>

<br>

(i) THE USE OR THE INABILITY TO USE THE SERVICE;<br>

<br>

(ii) THE COST OF PROCUREMENT OF SUBSTITUTE GOODS AND SERVICES RESULTING FROM ANY GOODS, DATA, INFORMATION OR SERVICES PURCHASED OR OBTAINED OR MESSAGES RECEIVED OR TRANSACTIONS ENTERED INTO THROUGH OR FROM THE SERVICE;<br>

<br>

(iii) UNAUTHORIZED ACCESS TO OR ALTERATION OF YOUR TRANSMISSIONS OR DATA;<br>

<br>

(iv) STATEMENTS OR CONDUCT OF ANY THIRD PARTY ON THE SERVICE; OR<br>

<br>

(v) ANY OTHER MATTER RELATING TO THE SERVICE. THIS LIMITATION OF LIABILITY STATEMENT APPLIES TO ADVERTISING AND LINKS PLACED ANYWHERE ON BOTH OUR PUBLIC SITE(" . $_SERVER['HTTP_HOST'] . ") AND OUR MEMBERS SITE. <br>

</p>

<p>12.  COPYRIGHTS and COPYRIGHT AGENTS<br>

  " . $_SERVER['HTTP_HOST'] . " respects the intellectual property of others, and we ask our users to do the same. This site is copyrighted &copy; and no duplications or reuse of any or part of its contents may be granted without the expressed written consent of " . $_SERVER['HTTP_HOST'] . ".<br>

<br>

</p>

<p>13. GENERAL INFORMATION<br>

  The section titles in the T &amp; C'S are for convenience only and have no legal or contractual effect.<br>

<br>

</p>

<p>14. REFUND POLICY<br>

  " . $_SERVER['HTTP_HOST'] . " has a 30 day, no questions asked money back guarantee on the sale of contact information for users who have built resumes using the " . $_SERVER['HTTP_HOST'] . " Resume Builder.  A &quot;set of contact information&quot; is defined as meaning the Name, Address, Telephone Number and Email address of a particular user of this site.  If you are not completely satisfied with the set of contact information you have purchased you may request a refund through Google Checkout.  Please allow 5-10 business days for us to process your request.  You may request a refund for 2 sets of contact information that you have bought, or for 40% of the sets  of contact information you have bought.  We will round down to the nearest whole number when we calculate the number of refunds the customer is eligible for.  For example, if you bought 3 sets of contact information, you would be eligible for 2 returns.  If you bought 9 sets, you would be eligible for 3 returns, because 40% of 9 is 3.6 and this would be rounded to 3.  If you bought 10 sets of contact information, you would be eligible for 4 returns, and so on.<br>

<br>

This returns policy does not affect your statutory rights.<br>

<p>

 15.  PRIVACY POLICY<br />

  We reserve the right to sell your personal information for $$basic_contact_information_price.  See our <a href=\"privacy_policy.php\">privacy policy</a> for details.  If you would like to remove your resume from our site, and thereby prevent us from selling your personal information, send an email to deans_ab@yahoo.com with the subject \"Request Remove\", and send the email from the email address you used when you created your resume (if you did so without creating an account) or the email address you used in the Create Account page when you created your account.

  Under no circumstances will users of this site be eligible to receive a share of the profits from the sale of their contact information.  

"

  ?>

