<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php



require("../buildsresumes.com/view/mid_google_ads.php");



if (isset($_POST['suggestion']))

{

echo "<br /><br />Your message has been sent.  Thank you for your feedback.<br /><br />";

echo "Below is the message you sent to " . $_SERVER['HTTP_HOST'] . ":<br /><br />" . $_POST['suggestion'] . "<br /><br />";







mail('byrondeans@gmail.com', 'Suggestion', $_POST['suggestion'] . $_SERVER['HTTP_HOST']);



unset($_POST['suggestion']);



}

require_once("view/mid_google_ads.php");

?> 

Contact Us:

<br /><br />

<form action="contact_us.php" method="post">

<textarea COLS="70" ROWS="6" name="suggestion"

>We value your feedback.</textarea><br />

<input type="submit" value="Submit Message" />

<br />



<br />

