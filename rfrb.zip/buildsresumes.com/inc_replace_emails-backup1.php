<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

$file = "/home2/bdeans108ajd/buildsresumes.com/testemailsforsite5-replace.txt";

$file2 = "/home2/bdeans108ajd/buildsresumes.com/testemailsforsite5.txt";

copy($file, $file2);



$j = 1;

$counter = 1;

while($j) {

    

    

    $f = fopen($file2, 'r');

    $line = fgets($f);

    print('$line is ' . $line . " Counter is $counter, j is $j  \r\n");

    //$line2 = fgets($f);

    //print('$line2 is ' . $line2 . "\r\n");

    //$line3 = fgets($f);

    //print('$line3 is ' . $line3 . "\r\n");

    //print('Length of $line3 is ' . strlen($line3));

    

    if(strlen($line) == 0) {

        $j = 0;

        print('At strlen 0, $j is ' . $j . "\r\n");

        continue;

    } else {

        read_and_delete_first_line($file2);

        print("Read and deleted line with when counter was $counter");

    }

    

    $array1 = explode(",", $line);

    

    $mysqli = mysqli_connect("localhost", "bdeans10_GO108", "jfitzgerald", "bdeans10_users");

    

    

    $user_id_encoded = $array1[3];

    $user_id_encoded = substr($user_id_encoded, 0, 49);

    $query = "SELECT `id`, `info` FROM `users` WHERE `user_id_encoded` = '$user_id_encoded';";

    $res = mysqli_query($mysqli, $query);

    print("array 1 is ");

    print_r($array1);

    while ($i = mysqli_fetch_assoc($res)) {

        print("In the inner while loop where counter is $counter");

        $file_user_contents = $i['info'];

        $pattern = '/(.*)emailcampaign1senttime/';

        $updated_file_user_contents_array = [];

        $is_match = preg_match($pattern, $file_user_contents, $updated_file_user_contents_array);

        if(isset($updated_file_user_contents_array[1])){

            $updated_file_user_contents = $updated_file_user_contents_array[1];

            $real_uid = $i['id'];

            $updatequery = "UPDATE `users` SET `info` = '" . $updated_file_user_contents . "' WHERE `id` = " . $real_uid;

            $res2 = mysqli_query($mysqli, $updatequery);

        } else {

            print("ERROR: file user contentsarray index 1 is missing.  Counter is $counter, fileusercontents is $file_user_contents");

        }

        //print("Updated file user contents are equal to $updated_file_user_contents");

        /*print($file_user_contents);

        $pattern = '/(.*)emailcampaign1senttime/';

        $updated_file_user_contents_array = [];

        //$file_user_contents = "first, Name";

        $is_match = preg_match($pattern, $file_user_contents, $updated_file_user_contents_array);

        print("is_match is $is_match");

        $updated_file_user_contents = $updated_file_user_contents_array;

        print_r($updated_file_user_contents_array);

        //print($updated_file_user_contents);

        */

    }

    

    $counter++;

    

}



$file = "/home2/bdeans108ajd/buildsresumes.com/testemailsforsite5-replace.txt";

$file2 = "/home2/bdeans108ajd/buildsresumes.com/testemailsforsite5.txt";

copy($file, $file2);



function read_and_delete_first_line($filename) {

  $file = file($filename);

  $output = $file[0];

  unset($file[0]);

  file_put_contents($filename, $file);

  return $output;

}

