<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

session_start();



?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"

        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html>

<head>

<title><?php echo $_SESSION['name'] . "\'s Resume";?></title>

<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<style type="text/css" media="screen">

li {

	font-size: 70%;

	margin: 0 0 3px 20px;

	padding: 0;

}

p {

	font-size: 70%;

	margin: 0 0 10px 0;

	padding: 0;

	width: 575px;

}

body ul {

	margin: 0 0 0 125px;

	padding: 0;

	width: 575px;

}

p, td, span, li, a { 

	font-family: verdana, arial, helvetica, sans-serif; 

}

body div ul {

	margin: 3px 0 0 0;

	padding: 0;

	width: 575px;

}

#left_name_address {

	font-size: 75%;

	float: left;

	width: 350px;

}

#right_name_address {

	font-size: 75%;

	float: left;

	text-align: right;

	width: 350px;

}

.company {

	clear: both;

	margin: 0 0 5px 0;

	padding: 0;

}

.location {

	clear: right;

	float: left;

	text-align: right;

	width: 125px;

}

.data {

	padding-left: 125px;

}

.date {

	clear: left;

	float: left;

	padding-top: 2px;

	width: 125px;

}

.job {

	clear: both;

	width: 700px;

}

.job_data {

	float: left;

	width: 575px;

}

body {

	margin: 10px;

}

h1 {

	font: 90% verdana, arial, helvetica, sans-serif;

	font-weight: bold;

	margin: 0 0 5px 0;

}

h2 {

	border-bottom: 1px solid #666;

	clear: both;

	font: 80% verdana, arial, helvetica, sans-serif;

	font-weight: bold;

	margin: 15px 0 10px 0;

	padding: 0 0 3px 0;

	width: 700px;

}

h3 {

	float: left;

	font: 80% verdana, arial, helvetica, sans-serif;

	font-weight: bold;

	margin: 0 0 5px 0;

	padding: 0;

	width: 446px;

}

.position {

	font-style: italic;

	margin: 0 0 5px 0;

}

#references {

	margin-top: 20px;

}

#meta {

	margin-top: 30px;

}

</style>

<style type="text/css" media="print">





li {

	font-size: 10pt;

	margin: 0 0 3px 5%;

	padding: 0;

}



p {

	font-size: 10pt;

	margin: 0 0 10px 0;

	padding: 0;

}

body ul {

	margin: 0 0 0 20%;

	padding: 0;

}

p, td, span, li, a { 

	font-family: verdana, arial, helvetica, sans-serif; 

}

body div ul {

	margin: 3px 0 0 0;

	padding: 0;

}

#left_name_address {

	font-size: 11pt;

	float: left;

	width: 50%;

}

#right_name_address {

	font-size: 11pt;

	float: left;

	text-align: right;

	width: 50%;

}

.company {

	clear: both;

	margin: 0 0 5px 0;

	padding: 0;

}

.location {

	clear: right;

	float: right;

	text-align: right;

	width: 20%;

}

.data {

	padding-left: 20%;

}

.date {

	clear: left;

	float: left;

	padding-top: 2px;

	width: 20%;

}

.job {

	clear: both;

	width: 100%;

}

.job_data {

	float: left;

	width: 80%;

}

body {

	margin: 0px;

}

h1 {

	font: 14pt verdana, arial, helvetica, sans-serif;

	font-weight: bold;

	margin: 0 0 5px 0;

}

h2 {

	border-bottom: 1px solid #666;

	clear: both;

	font: 11pt verdana, arial, helvetica, sans-serif;

	font-weight: bold;

	margin: 15px 0 10px 0;

	padding: 0 0 3px 0;

	width: 100%;

}

h3 {

	font: 11pt verdana, arial, helvetica, sans-serif;

	font-weight: bold;

	margin: 0 0 2px 0;

	padding: 0;

}

.position {

	font-style: italic;

	margin: 0 0 5px 0;

}

#references {

	margin-top: 20px;

}

#meta {

	display: none;

}

</style>





</head>



<body>



<h1><?php echo $_SESSION['name']; ?></h1>



<p id="left_name_address">

<?php echo $_SESSION['phone']; ?><br />	<?php echo $_SESSION['email']; ?>

</p>

<p id="right_name_address">

<?php echo $_SESSION['address_line_1']; ?><br /><?php echo $_SESSION['address_line_2']; ?></p>



<h2>OBJECTIVE</h2>

<p class="data"><?php echo $_SESSION['objective']; ?></p>



<h2>EMPLOYMENT HISTORY</h2>



<?php

for ($i = 1; $i <= $_SESSION['number_employer'];$i++)

{

	$employer_name = "employer" . $i . "_name";

	$employer_dates = "employer" . $i . "_dates";

	$employer_type = "employer" . $i . "_type";

	$employer_location = "employer" . $i . "_location";

	$employer_url = "employer" . $i . "_url";

	$job_title = "employer" . $i . "_job_title";

	

	echo "<div class=\"job\">";

	echo "<p class=\"date\">$_SESSION[$employer_dates]</p>";

	echo "<div class=\"job_data\"><h3>";

	

	

	if ($_SESSION[$employer_url] != "")

	echo "<a href=\"$_SESSION[$employer_url]\">";

	

	echo $_SESSION[$employer_name];

	

	if ($_SESSION[$employer_url] != "")

	echo "</a>";

	

	

	echo "</h3><p class=\"location\">$_SESSION[$employer_location]</p>";

	echo "<p class=\"company\">$_SESSION[$employer_type]</p>";

	echo "<p class=\"position\">$_SESSION[$job_title]</p>";

	

	

	$number_accomplishments = "employer" . $i . "_number_accomplishments";

	$employer_i_accomplishment = "employer" . $i . "_accomplishment";

	

	for ($j = 1;$j <= $_SESSION[$number_accomplishments];$j++)

	{

		$employer_i_accomplishmentj = "employer$i" . "_accomplishment$j";

		echo "<ul><li>" . "$_SESSION[$employer_i_accomplishmentj]" . "</li></ul>";

	}

	

	echo "&nbsp;</div></div>";



}



?>



<h2>PROJECTS AND SKILLS</h2>



<?php

	echo "<ul>";

for ($i = 1; $i <= $_SESSION['number_skills'];$i++)

{

	$skill = "skill$i";

	echo "<li>$_SESSION[$skill]</li>";

}

	echo "</ul>";

?>





<h2>EDUCATION</h2>

<?php

	echo "<ul>";

for ($i = 1; $i <= $_SESSION['number_education'];$i++)

{

	$education = "education$i";

	echo "<li>$_SESSION[$education]</li>";

}

	echo "</ul>";

?>



<h2>INTERESTS &amp; HOBBIES</h2>

<?php

	echo "<ul>";

for ($i = 1; $i <= $_SESSION['number_interest'];$i++)

{

	$interest = "interest$i";

	echo "<li>$_SESSION[$interest]</li>";

}

	echo "</ul>";

?>



</body>

</html>

