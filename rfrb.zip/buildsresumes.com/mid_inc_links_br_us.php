<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php require("../buildsresumes.com/view/mid_google_ads.php"); 



if(isset($_GET['resume_advice'])) {

require("view/resume_advice_br_us.php");

die("");

}

elseif(isset($_GET['cover_letter_advice'])) {

require("view/cover_letter_advice_br_us.php");

die("");

}

elseif(isset($_GET['jobs_boards'])) {

require("view/jobs_boards_br_us.php");

die("");

}



?>

<!-- SiteSearch Google -->

<form method="get" action="http://www.google.com/custom" target="_top">

<table border="0" bgcolor="#cccccc">

<tr><td nowrap="nowrap" valign="top" align="left" height="32">

<a href="http://www.google.com/">

<img src="http://www.google.com/logos/Logo_25gry.gif" border="0" alt="Google" align="middle"></img></a>

</td>

<td nowrap="nowrap">

<input type="hidden" name="domains" value="www.ReallyFreeResumeBuilder.com"></input>

<label for="sbi" style="display: none">Enter your search terms</label>

<input type="text" name="q" size="31" maxlength="255" value="" id="sbi"></input>

<label for="sbb" style="display: none">Submit search form</label>

<input type="submit" name="sa" value="Search" id="sbb"></input>

</td></tr>

<tr>

<td>&nbsp;</td>

<td nowrap="nowrap">

<table>

<tr>

<td>

<input type="radio" name="sitesearch" value="" checked id="ss0"></input>

<label for="ss0" title="Search the Web"><font size="-1" color="#000000">Web</font></label></td>

<td>

<input type="radio" name="sitesearch" value="www.ReallyFreeResumeBuilder.com" id="ss1"></input>

<label for="ss1" title="Search www.ReallyFreeResumeBuilder.com"><font size="-1" color="#000000">www.ReallyFreeResumeBuilder.com</font></label></td>

</tr>

</table>

<input type="hidden" name="client" value="pub-7032194388951945"></input>

<input type="hidden" name="forid" value="1"></input>

<input type="hidden" name="ie" value="ISO-8859-1"></input>

<input type="hidden" name="oe" value="ISO-8859-1"></input>

<input type="hidden" name="cof" value="GALT:#008000;GL:1;DIV:#336699;VLC:663399;AH:center;BGC:FFFFFF;LBGC:336699;ALC:0000FF;LC:0000FF;T:000000;GFNT:0000FF;GIMP:0000FF;FORID:1"></input>

<input type="hidden" name="hl" value="en"></input>

</td></tr></table>

</form>

<!-- SiteSearch Google -->

<br /><br />

<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Resume / CV Advice</b></font>

<br /><br />

Your resume should always be custom tailored for each employer (mainly, your "objective" statement is what will 



reflect this.)  Never lie on your resume.  If possible, research the contact name of someone at the company, and 



address the cover letter to that person.<br /><br />



When listing responsibilities, always list your most important ones first, don't necessarily list them in the order of 



how much time you spent with them.  If possible, support your claims with facts that an employer can check: numbers 



are especially powerful, e.g. "reduced legal exposure by 50%."<br /><br />



<a href="<?php $PHP_SELF; ?>?resume_advice=TRUE">More Resume Advice</a>

<br /><br /><br /><br />



<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Cover Letter Advice</b></font>

<br /><br />

1st Paragraph: who you are.  Your relationship with the person you are contacting or where you heard about the position you are applying to.  Also, its best to include knowledge of the company and job you are applying for (the more you impress them with this knowledge, the better.)

<br /><br />

<a href="<?php $PHP_SELF; ?>?cover_letter_advice=TRUE">More Cover Letter Advice</a>

<br /><br /><br /><br />





<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Jobs Boards</b></font>

<br /><br />

Services that match your resume to available jobs and make your resume available to employers.

<br /><br />

<a href="<?php $PHP_SELF; ?>?jobs_boards=TRUE">Jobs Boards</a>



<br /><br /><br /><br />

<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Miscellaneous</b></font>

<br /><br />A highly recommended web browser, if you don't already have it.<br /><br />

<script type="text/javascript"><!--

google_ad_client = "pub-7032194388951945";

//180x60, created 12/13/07

google_ad_slot = "7560585015";

google_ad_width = 180;

google_ad_height = 60;

google_cpa_choice = ""; // on file

//--></script>

<script type="text/javascript"

src="http://pagead2.googlesyndication.com/pagead/show_ads.js">

</script>



