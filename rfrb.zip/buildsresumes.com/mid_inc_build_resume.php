<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php 

//require("../buildsresumes.com/view/mid_google_ads.php");



if (isset($_SESSION['suggestion']))

{

echo "Suggestion sent";







mail('deans_ab@yahoo.com', 'Suggestion', $_SESSION['suggestion']);



unset($_SESSION['suggestion']);



}

?> 

<SCRIPT language="JavaScript">

function submitform(location)

{

  if(location){

  document.resume_form.action = 'build_resume.php?' + location;

  }



  document.resume_form.submit();

}

</SCRIPT>

<div style="float: left; margin-bottom: 0px"> 



<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7032194388951945"

     crossorigin="anonymous"></script>

<!-- 468x60, created 7/27/10 -->

<ins class="adsbygoogle"

     style="display:inline-block;width:468px;height:60px"

     data-ad-client="ca-pub-7032194388951945"

     data-ad-slot="2985304124"></ins>

<script>

     (adsbygoogle = window.adsbygoogle || []).push({});

</script>





</div>



&nbsp;<hr />&nbsp;

<h3>Resume: <a href="resume.php" target="_blank">Preview</a> or you can also <a href="resume.php?force_download=1">Download It</a></h3>

<form name="resume_form" action="build_resume.php" method="post">

<input name="coming_from" type="hidden" value="build_resume">

<br /><h6>Use of this site and resume template is subject to <a href="terms_of_use.php">Terms &amp; Conditions of Use</a></h6><br /><br />

<?php 





if(isset($_SESSION['logged_in']))

echo "Welcome " . $_SESSION['screen_name'] . " &nbsp; <a href=\"build_resume.php?sign_out=1\">Sign Out</a>";

else {

echo "<a href=\"sign_in.php\">Sign-in</a><br />";

echo "<a href=\"create_user.php\">Create a new account</a> (to store your resume for later editing.)<br />";

}

//from below <br /><a href="edit_profile.php" >Edit Cover Letter / Profile</a>



?>

<br /><br /><br />



<?php

/*

if(isset($_SESSION['screen_name'])) {

	echo "Make Profile Public <input name=\"make_profile_public\" type=\"checkbox\" value=\"1\"";



	if($_SESSION['make_profile_public'] == 1)

	echo "checked"; 

	

	echo " />&nbsp; <a href=\"profile.php?profile_for=" . $_SESSION['screen_name'] . "\">View Profile</a>";

	

}

*/

?>



<h3><a name="name_contact">Name and Contact Information</a></h3>





<table>

<tr>

	<td>Name: &nbsp;</td>

	<td>

<input type="text" size="55" name="name" value="<?php if(isset($_SESSION['name'])) echo $_SESSION['name']; else echo "Your Name"; ?>" /><br />

	</td>

<tr>

	<td>Address Line 1: &nbsp;</td>

	<td>

<input type="text" size="55" name="address_line_1" value="<?php if(isset($_SESSION['address_line_1'])) echo $_SESSION['address_line_1']; else echo "123 N.E. St.";?>" /><br />

	</td>

</tr>

<tr>

	<td>Address Line 2: &nbsp;</td>

	<td>

<input type="text" size="55" name="address_line_2" value="<?php if(isset($_SESSION['address_line_2'])) echo $_SESSION['address_line_2']; else echo "Boone, NC, USA    28607";?>" /><br />

	</td>

</tr>

<tr>

	<td>Email:&nbsp;</td>

	<td>

<input type="text" size="55" name="email" value="<?php if(isset($_SESSION['email'])) echo $_SESSION['email']; else echo "yourname@airivanhoe.com";?>" /><br />

	</td>

</tr>

<tr>

	<td>Phone:&nbsp;</td>

	<td>

<input type="text" size="55" name="phone" value="<?php if(isset($_SESSION['phone'])) echo $_SESSION['phone']; else echo "555-555-5555";?>" /><br />

	</td>

</tr>

</table>



<br /><input onclick="submitform('#name_contact'); return false" type="submit" value="Save" /><br /><br />



<h3><a name="objective">Summary</a></h3>



<input type="text" name="objective" size="70" value="<?php if(isset($_SESSION['objective'])) echo $_SESSION['objective']; else echo "Type Summary Here - Hint: this includes years of experience, and what you've been doing"?>" />

<br /><br /><input onclick="submitform('#name_contact'); return false" type="submit" value="Save" />

<br /><br />



<a name="employer_1"><h3>Employment History</h3></a>





<a href="build_resume.php?add_employer_here=employer1#employer_1" onclick="submitform('add_employer_here=employer1#employer_1'); return false" name="employer_0">Add Employer Here</a><br /><br />



<?php

$number_employer = $_SESSION['number_employer'];

for ($i = 1;$i <= $_SESSION['number_employer'];$i++)

{

	$employer_name = "employer" . $i . "_name";

	if (!isset($_SESSION[$employer_name]))

	$_SESSION[$employer_name] = "Type Employer Name Here";

	

	$employer_dates = "employer" . $i . "_dates";

	if (!isset($_SESSION[$employer_dates]))

	$_SESSION[$employer_dates] = "2000-2005 (for example)";

	

	$employer_type = "employer" . $i . "_type";

	if (!isset($_SESSION[$employer_type]))

	$_SESSION[$employer_type] = "Food Service Company (for example)";

	

	$employer_location = "employer" . $i . "_location";

	if (!isset($_SESSION[$employer_location]))

	$_SESSION[$employer_location] = "";

	

	$job_title = "employer" . $i . "_job_title";

	if (!isset($_SESSION[$job_title]))

	$_SESSION[$job_title] = "";

	

	$employer_url = "employer" . $i . "_url";

	if (!isset($_SESSION[$employer_url]))

	$_SESSION[$employer_url] = "";

	

	$i_minus_one = $i - 1;

	$i_plus_one = $i + 1;

	

	echo "<table>";

	echo "<tr><td>Employer $i Name:&nbsp;</td><td><input type=\"text\" size=\"55\" name=\"$employer_name\"

	value=\"$_SESSION[$employer_name]\" size=\"30\" /></td></tr>";

	

	echo "<tr><td>Dates of employment:&nbsp;</td><td><input type=\"text\" size=\"55\" name=\"$employer_dates\"

	value=\"$_SESSION[$employer_dates]\" size=\"30\" /></td></tr>";

	

	echo "<tr><td>Type of employer:&nbsp;</td><td><input type=\"text\" size=\"55\" name=\"$employer_type\"

	value=\"$_SESSION[$employer_type]\" size=\"30\" /></td></tr>";

	

	echo "<tr><td>Location of employer:&nbsp;</td><td><input type=\"text\" size=\"55\" name=\"$employer_location\"

	value=\"$_SESSION[$employer_location]\" size=\"30\" /></td></tr>";



	echo "<tr><td>Title:&nbsp;</td><td><input type=\"text\" size=\"55\" name=\"$job_title\"

	value=\"$_SESSION[$job_title]\" size=\"30\" /></td></tr>";	

	

	echo "<tr><td>Employer URL:&nbsp;</td><td><input type=\"text\" size=\"55\" name=\"$employer_url\"

	value=\"$_SESSION[$employer_url]\" size=\"30\" /></td></tr>";

	echo "</table>";

	echo "Enter full URL: e.g. http://www.apple.com (leave blank if none available)<br />";

	if(isset($_SESSION[$employer_name]) && $_SESSION[$employer_name] != "")

	$employer = $_SESSION[$employer_name];

	else

	$employer = "$i";

	

	//echo "<a href=\"build_resume.php?remove_employer_here=$i&number_employer=$number_employer#employer_$i_minus_one\">Remove Employer $employer</a><br /><br />";

	//echo "<a href=\"javascript: submitform('remove_employer_here=$i&number_employer=$number_employer#employer_$i_minus_one')\">Remove Employer $employer</a><br /><br />";

        echo "<a href=\"build_resume.php?remove_employer_here=$i&number_employer=$number_employer#employer_$i_minus_one\" onclick=\"submitform('remove_employer_here=$i&number_employer=$number_employer#employer_$i_minus_one'); return false\">Remove Employer $employer</a><br /><br />";



	$number_accomplishments = "employer" . $i . "_number_accomplishments";

	$employer_i_accomplishment = "employer" . $i . "_accomplishment";

	

	if (!isset($_SESSION[$number_accomplishments]))

	$_SESSION[$number_accomplishments] = 1;







	$add_employer_i_accomplishment = "employer" . $i . "_add_accomplishment";

	if (isset($_GET[$add_employer_i_accomplishment])) {

	$get_num_accomp = $_GET['number_accomplishments'];

	settype($get_num_accomp, 'int');

	if($_SESSION[$number_accomplishments] == $get_num_accomp)

		$_SESSION[$number_accomplishments]++;

	}





	$remove_employer_i_accomplishment = "employer" . $i . "_remove_accomplishment";

	if (isset($_GET[$remove_employer_i_accomplishment]) && $_SESSION[$number_accomplishments] > 1) {

	$get_num_accomp = $_GET['number_accomplishments'];

	settype($get_num_accomp, 'int');

	if($_SESSION[$number_accomplishments] == $get_num_accomp)

		$_SESSION[$number_accomplishments]--;

	}



	for ($j =1;$j <= $_SESSION[$number_accomplishments];$j++)

	{

		$employer_i_accomplishmentj = "employer$i" . "_accomplishment$j";

		if (!isset($_SESSION[$employer_i_accomplishmentj]))

		$_SESSION[$employer_i_accomplishmentj] = "Accomplishment $j";

		

		echo "Accomplishment $j:&nbsp;<input type=\"text\" name=\"employer$i" . "_accomplishment$j\" 

		value=\"$_SESSION[$employer_i_accomplishmentj]\" size=\"70\" /><br />";

		

		if($j >= $_SESSION[$number_accomplishments]) {

			//echo "<a href=\"build_resume.php?$add_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i\">Add Accomplishment</a>";

                        //echo "<a href=\"javascript: submitform('$add_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i')\">Add Accomplishment</a>";

                        echo "<a href=\"build_resume.php?$add_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i\" onclick=\"submitform('$add_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i'); return false\">Add Accomplishment</a>";

                        

			//echo "&nbsp;Hint:  Always click \"Save\" before adding.  Add as many fields as needed before entering information, then click \"Save\"";

		

			if ($_SESSION[$number_accomplishments] > 1)

			//echo "<br /><a href=\"build_resume.php?$remove_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i\">Remove Accomplishment</a>";

                        //echo "<br /><a href=\"javascript: submitform('$remove_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i')\">Remove Accomplishment</a>";

                        echo "<br /><a href=\"build_resume.php?$remove_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i\" onclick=\"submitform('$remove_employer_i_accomplishment=1&number_accomplishments=$_SESSION[$number_accomplishments]#employer_$i'); return false\">Remove Accomplishment</a>";



			echo "<br /><br />";

		}

	}



echo "<br /><table ><tr><td>&nbsp;<img src=\"widgets/spacer.gif\" height=5 width=\"225\" alt=\"\"></td><td><a href=\"build_resume.php?add_employer_here=employer$i_plus_one&number_employer=$number_employer#employer_$i\" onclick=\"submitform('add_employer_here=employer$i_plus_one&number_employer=$number_employer#employer_$i'); return false\" name=\"employer_$i_plus_one\">Add Employer Here</a>&nbsp; <input onclick=\"submitform('#employer_$i'); return false\" type=\"submit\" value=\"Save\" /></td></tr></table>

<br /><br /><br />";



//echo "<br /><table ><tr><td>&nbsp;<img src=\"widgets/spacer.gif\" height=5 width=\"225\" alt=\"\"></td><td><a href=\"javascript: submitform('add_employer_here=employer$i_plus_one&number_employer=$number_employer#employer_$i')\" name=\"employer_$i_plus_one\">Add Employer Here</a>&nbsp; <input type=\"submit\" value=\"Save\" /></td></tr></table>

//<br /><br /><br />";



//echo "<br /><table ><tr><td>&nbsp;<img src=\"widgets/spacer.gif\" height=5 width=\"225\" alt=\"\"></td><td><a href=\"build_resume.php?add_employer_here=employer$i_plus_one&number_employer=$number_employer#employer_$i\" name=\"employer_$i_plus_one\">Add Employer Here</a>&nbsp; <input type=\"submit\" value=\"Save\" /></td></tr></table>

//<br /><br /><br />";

}

?>

    <br />

   

    <br />

    <br />

  

    <br />



<h3><a name="projects_skills">Projects and Skills</a></h3>





<?php

$number_skills = $_SESSION['number_skills'];

$number_skills_plus = $_SESSION['number_skills'] + 1;

$number_skills_minus = $_SESSION['number_skills'] -1;

for ($i = 1;$i <= $number_skills; $i++)

{

	$skill = "skill$i";

	echo "Project/Skill $i:&nbsp;<input type=\"text\" size=\"70\" name=\"$skill\" value=\"";

	if (isset($_SESSION[$skill]))

	echo $_SESSION[$skill];

	else

	echo "Skill $i";

	

	echo "\" /><br />";



	if ($i >= $number_skills)

	{

	//javascript: submitform('add_employer_here=employer$i_plus_one&number_employer=$number_employer#employer_$i')

	//echo "<a href=\"build_resume.php?add_skill=$number_skills_plus&number_skill=$number_skills#projects_skills\">Add Skill</a>";

	//echo "<a href=\"javascript: submitform('add_skill=$number_skills_plus&number_skill=$number_skills#projects_skills')\">Add Skill</a>";

        echo "<a href=\"build_resume.php?add_skill=$number_skills_plus&number_skill=$number_skills#projects_skills\" onclick=\"submitform('add_skill=$number_skills_plus&number_skill=$number_skills#projects_skills'); return false\">Add Skill</a>";

        //echo "&nbsp;Hint:  Always click \"Save\" before adding.  Add as many fields as needed before entering information, then click \"Save\"";

	

	if ($_SESSION['number_skills'] > 1)

	//echo "<br /><a href=\"build_resume.php?remove_skill=$number_skills_minus&number_skills=$number_skills#projects_skills\">Remove Skill</a>";

	//echo "<br /><a href=\"javascript: submitform('remove_skill=$number_skills_minus&number_skills=$number_skills#projects_skills')\">Remove Skill</a>";

        echo "<br /><a href=\"build_resume.php?remove_skill=$number_skills_minus&number_skills=$number_skills#projects_skills\" onclick=\"submitform('remove_skill=$number_skills_minus&number_skills=$number_skills#projects_skills'); return false\">Remove Skill</a>";



	

	echo "<br /><br /><input onclick=\"submitform('#projects_skills'); return false\" type=\"submit\" value=\"Save\" /><br />";

	}



}

?>

<br />



<br />

<h3><a name="education">Education</a></h3>



<?php

$number_education = $_SESSION['number_education'];

$number_education_plus = $_SESSION['number_education'] + 1;

$number_education_minus = $_SESSION['number_education'] - 1;

for ($i = 1;$i <= $_SESSION['number_education']; $i++)

{

	$education = "education$i";

	echo "Education $i:&nbsp;<input type=\"text\" size=\"70\" name=\"$education\" value=\"";

	if (isset($_SESSION[$education]))

	echo $_SESSION[$education];

	

	echo "\" /><br />";



	if ($i >= $_SESSION['number_education'])

	{

	//echo "<a href=\"build_resume.php?add_education=$number_education_plus&number_education=$number_education#education\">Add education</a>";

        //echo "<a href=\"javascript: submitform('add_education=$number_education_plus&number_education=$number_education#education')\">Add education</a>";

	//javascript: submitform('remove_skill=$number_skills_minus&number_skills=$number_skills#projects_skills')

        echo "<a href=\"build_resume.php?add_education=$number_education_plus&number_education=$number_education#education\" onclick=\"submitform('add_education=$number_education_plus&number_education=$number_education#education'); return false\">Add Skill</a>";



        //echo "&nbsp;Hint:  Always click \"Save\" before adding.  Add as many fields as needed before entering information, then click \"Save\"";

	

	if ($_SESSION['number_education'] > 1)

	//echo "<br /><a href=\"build_resume.php?remove_education=$number_education_minus&number_education=$number_education#education\">Remove education</a>";

	//echo "<br /><a href=\"javascript: submitform('remove_education=$number_education_minus&number_education=$number_education#education')\">Remove education</a>";

        echo "<br /><a href=\"build_resume.php?remove_education=$number_education_minus&number_education=$number_education#education\" onclick=\"submitform('remove_education=$number_education_minus&number_education=$number_education#education'); return false\">Remove education</a>";



	echo "<br /><br /><input onclick=\"submitform('#education'); return false\" type=\"submit\" value=\"Save\" /><br />";

	}



}

?>

<?php /*

<h3><a name="interests">Interests and Hobbies</a></h3>



<?php

$number_interests = $_SESSION['number_interest'];

$number_interests_plus = $_SESSION['number_interest'] + 1;

$number_interests_minus = $_SESSION['number_interest'] - 1;

for ($i = 1;$i <= $number_interests; $i++)

{

	$interest = "interest$i";

	echo "Interest $i:&nbsp;<input type=\"text\" size=\"70\" name=\"$interest\" value=\"";

	if (isset($_SESSION[$interest]))

	echo $_SESSION[$interest];

	

	echo "\" /><br />";



	if ($i >= $number_interests)

	{

	//echo "<a href=\"build_resume.php?add_interest=$number_interests_plus&number_interests=$number_interests#interests\">Add interest</a>";

        echo "<a href=\"javascript: submitform('add_interest=$number_interests_plus&number_interests=$number_interests#interests')\">Add interest</a>";

	//javascript: submitform('remove_education=$number_education_minus&number_education=$number_education#education')

        echo "&nbsp;Hint:  Always click \"Save\" before adding.  Add as many fields as needed before entering information, then click \"Save\"";

	

	if ($number_interests > 1)

	//echo "<br /><a href=\"build_resume.php?remove_interest=$number_interests_minus&number_interests=$number_interests#interests\">Remove interest</a>";

	echo "<br /><a href=\"javascript: submitform('build_resume.php?remove_interest=$number_interests_minus&number_interests=$number_interests#interests')\">Remove interest</a>";



	echo "<br /><br /><input type=\"submit\" value=\"Save\" /><br />";

	}



}

*/

?>

<br />

<a href="resume.php">Preview Resume</a>&nbsp;(Hint: Click "Save" before previewing if you have made any changes.) 

</form>
