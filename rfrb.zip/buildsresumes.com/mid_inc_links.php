<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php //require("../buildsresumes.com/view/advice_and_links.php");

//require("../buildsresumes.com/view/mid_google_ads_cover_letter.php");

?>

<br />

<a href="coverletter.php">How to Write a Cover Letter</a>  - An original article from this site

<br /><br /><br />





<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Career Advancement Books</b></font>



<br /><br />

<iframe type="text/html" width="336" height="550" frameborder="0" allowfullscreen style="max-width:100%" src="https://read.amazon.co.uk/kp/card?asin=B08YY5H8KR&preview=inline&linkCode=kpe&ref_=cm_sw_r_kb_dp_8YP3ZC6FQJ0VWE87S1Z7&tag=abyrondeansco-20" ></iframe>



<br /><br />



<!--

<a href="http://www.amazon.com/gp/product/1580089879?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=1580089879">What Color Is Your Parachute?  A Practical Manual for Job-Hunters and Career-Changers (Paperback) - Click here to purchase!!! - $12.09 from Amazon.com</a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=1580089879" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />





<br /><br />



<div style="float: left; clear:both; margin-bottom:15px;">

<a href="http://www.amazon.com/gp/product/1580089879?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=1580089879"><img style="float: left; margin-right: 2px;" src="what_color_is_your_parachute.png" /></a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=1580089879" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />

-->

Author Richard N. Bolles consistently cranks out one of the best job-hunting books in the universe.  He has a witty and colloquial style that is engaging and takes the depression and slavework out of the job hunt.  He informs the audience how to get through to and engage "the person who has the power to hire you" and land a job, and not just any job, but one that you'll be happy in.  His book is rightly the most well respected job-hunting book out there.



<br /><br />



<iframe type="text/html" width="336" height="550" frameborder="0" allowfullscreen style="max-width:100%" src="https://read.amazon.co.uk/kp/card?asin=B002IPZJ7Y&preview=inline&linkCode=kpe&ref_=cm_sw_r_kb_dp_4X4RQ6M2M22HDVXMBCC3&tag=abyrondeansco-20" ></iframe>



<br /><br />



<!--

</div>





<br /><br />

<a href="http://www.amazon.com/gp/product/0767916239?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=0767916239">The Perfect Resume: Today's Ultimate Job Search Tool (Paperback) - Click here to purchase!!! - $11.90 from Amazon.com</a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=0767916239" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />



<br /><br />



<div style="float: left; clear:both; margin-bottom:15px;">



<a href="http://www.amazon.com/gp/product/0767916239?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=0767916239"><img style="float: left; margin-right: 2px;" src="the_perfect_resume.png" /></a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=0767916239" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />

This book is sometimes slow, but is written by Tom Jackson, the leader in the resume field, so it deserves a careful look.  It will show you how to find a suitable career, and then how to write a resume that highlights your strengths.

</div>



<a href="http://www.amazon.com/gp/product/0425230554?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=0425230554">Fired to Hired: Bouncing Back from Job Loss to Get to Work Right Now - Click here to purchase!!! - $10.98 from Amazon.com</a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=0425230554" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />



<br /><br />



<div style="float: left; clear:both; margin-bottom:15px;">





<a href="http://www.amazon.com/gp/product/0425230554?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=0425230554"><img style="float: left; margin-right: 2px;" src="fired_to_hired.png" /></a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=0425230554" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />



This book is a great read and will kick start your enthusiasm to job search.  Spelling is practical and tells her own career story as well as other stories about people bouncing back from job loss.  She gives practical advice on managing your job search as well as managing your life and finances while you are between jobs.  One of the more refreshing pieces of advice is to form a 'job search club' with friends which not only helps you network with job hunters but also boosts your psychological health.  In this reviewer's opinion staying happy and balanced during a job search is vital.  She gives excellent advice on working from home and includes a list of companies that hire home based employees or consultants. Everyone will benefit from this book ... and perhaps especially women over 35.

</div>



<a href="http://www.amazon.com/gp/product/1598699164?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=1598699164">The Work-at-Home Success Bible: A Complete Guide for Women:  Start Your Own Business; Balance Work and Home Life; Develop Telecommuting Strategies - Click here to purchase!!! - $10.17 from Amazon.com</a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=1598699164" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />



<br /><br />



<div style="float: left; clear:both; margin-bottom:30px;">

<a href="http://www.amazon.com/gp/product/1598699164?ie=UTF8&tag=higonher-20&linkCode=as2&camp=1789&creative=390957&creativeASIN=1598699164"><img style="float: left; margin-right: 2px;" src="will_work_from_home.png" /></a><img src="http://www.assoc-amazon.com/e/ir?t=higonher-20&l=as2&o=1&a=1598699164" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />



This is the best book about working from home.  It outlines many, many opportunities for those who are motivated to work and are willing to adapt their skills for a home based career.  It is very upbeat and inspiring and will shake the cobwebs from your old impressions about job hunting.



</div>

-->

<br /><br />

<FONT COLOR="#472B29" SIZE="3" FACE="ms sans serif, arial, helvetica" style="margin-right:5px;"><b>Career Sites</b></font>

<br /><br />These jobs boards let you post your resume for employers and recruiters to see.  They also have lists of positions you can apply for.<br /><br />

<p><a href="http://www.monster.com

">Monster.com</a>  A very famous one.</p>

<p><a href="https://www.careerbuilder.com">Careerbuilder.com</a></p>

<p><a href="https://www.snagajob.com">Snagajob.com</a></p>

<p><a href="https://www.fiverr.com">Fiverr.com</a> Focuses on freelancers.</p>

<p><a href="https://www.upwork.com">Upwork.com</a> They kicked me off after I had built up positive feedback for the most corrupt sounding reasons, but if you're into that sound...</p>



<p><a href="https://stackoverflow.com/jobs">Stack Overflow Jobs</a> For developers

<p><a href="https://www.totaljobs.com">TotalJobs</a></p>

<p><a href="https://wellpaid.io/">Wellpaid.io</a> Contracting </p>

<p><a href="https://www.freelancer.com">Freelancer</a></p>

<p><a href="https://www.giggrabbers.com">Gigrabbers</a></p>

<p><a href="https://app.communo.com/feed">Communo</a></p>

<p><a href="https://www.workatastartup.com">Workatastartup</a> For startups at the famous Y Combinator venture capital fund</p>

<p><a href="https://www.crunchboard.com">Crunchboard</a></p>





<p><a href="https://arc.dev">Arc</a> Remote developer jobs</p>

<p><a href="remoteok.io">Remote OK</a></p>

<p><a href="https://www.letsworkremotely.com">letsworkremotely</a></p>

<p><a href="https://workew.com">Workew</a></p>
