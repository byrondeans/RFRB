<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

require("prices.php");

echo "PRIVACY POLICY:<br /><br />



We reserve the right to sell the contact information of users of this site for $$basic_contact_information_price (price will change from time to time.)  <br />

<br />If you do not want your contact information to be sold, simply omit the \"Phone\" field when you create your resume and do not create an account.  You can then edit your resume using a program such as Notepad, and add the phone number by hand under id=\"left_name_address\" (just search for this string.)



If you would like your resume to be removed from the site, simply email deans_ab@yahoo.com from the same email address you signed up with (or created your resume with) and put \"Request Remove\" in the subject field.



"

//<!-- If you have an account, you can turn off the Sell My Contact Information to Interested Employers checkbox in the My Account Settings page. -->

?>
