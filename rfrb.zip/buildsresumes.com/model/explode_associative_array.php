<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php  //$file_user_contents should be preset to the contents of ";;;" and "===" separated text

function explode_associative_array($file_user_contents) {

	$the_file_contents_array = array();

	$fc_array = explode (";;;", $file_user_contents);

	  foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		/*if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop */

		if (!isset($key_value_pair[1]))

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $the_file_contents_array[$key] = $value;

     }

	return $the_file_contents_array;

}

?>
