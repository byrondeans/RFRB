<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

//die("We're sorry, sign in is temporarily unavailable" );

/*If not trying to email forgotten password, this will execute */

/*check Username/email password combination */



/*

if (isset($_POST['email_address']) && file_exists($_POST['email_address'].".txt")) {

	

	

	$file_opened = fopen($_POST['email_address'].".txt", "r");

    $file_contents = fread ($file_opened, filesize($_POST['email_address'].".txt"));

 */

if (isset($_POST['signing_in'])) {

   

//$con -= mysql_connect("localhost", "bdeans10_GO108", "jfitzgerald");		

/*$con -= mysql_connect("localhost", "root", "");*/

	//OLD require("database_access.php");

    //$mysqli = new mysqli("localhost", "bdeans10_GO108", "jfitzgerald", "bdeans10_users");

    

	//OLD mysql_select_db("bdeans10_users",$con);

	$screen_name = $_POST['screen_name'];

	

	

	$query = "SELECT info, session FROM users WHERE screen_name='" . $_POST['screen_name'] . "'";

	//OLD $result = mysql_query($query);

	//print("Query is " . $query);

    

    $mysqli = mysqli_connect("localhost", "bdeans10_GO108", "jfitzgerald", "bdeans10_users");

    $res = mysqli_query($mysqli, $query);

    //$row = mysqli_fetch_assoc($res);

    

    //$result = $mysqli->use_result();

    

    // debugging code   die("Result is " .  var_dump($result));

    //echo "passed con->use_result";

    

	$file_user_contents = "";

	$session_contents = "";

	

    while ($i = mysqli_fetch_assoc($res)) {

        

        $file_user_contents = $i['info'];

        //die($file_user_contents);

        

        $session_contents = $i['session'];

    }

    /*OLD

	while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

	$file_user_contents = $i['info'];

	$session_contents = $i['session'];

	}

    */

	

	if ($file_user_contents == "")

	die ("Error, no data found in database for $screen_name");

	

	

	$fc_array = explode (";;;", $file_user_contents);

    $the_file_contents_array = array("one" => "declared");

    

    foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		/*if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop */

		if (!isset($key_value_pair[1]))//we've reached the end

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $the_file_contents_array[$key] = $value;

    }

	/* double check that email_address.txt matches email_address contained inside 

	if ($_POST['screen_name'] != $the_file_contents_array['username'])

	die ("Wrong email");*/



    if ($_POST['password'] != $the_file_contents_array['password1'])

    die("Wrong password");

	

	

	

	//LOAD DATA FROM SESSION COLUMN OF DATABASE INTO $_SESSION SUPERGLOBAL ARRAY

	$fc_array = explode (";;;", $session_contents);

    $session_contents_array = array("one" => "declared");

    

    foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		//if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop

		if (!isset($key_value_pair[1]))

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $session_contents_array[$key] = $value;

    }





	foreach ($session_contents_array as $key => $i)

	{

		$_SESSION[$key] = $i;

	}



	//THE OLD WAY USING FILES

	/* Password is correct */

	/*

	$file_opened = fopen($_POST['screen_name']."-SESSION.txt", "r");

    $file_contents = fread ($file_opened, filesize($_POST['screen_name']."-SESSION.txt"));

    $fc_array = explode (";;;", $file_contents);

    $the_session_file_contents_array = array("one" => "declared");

    

    foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		//if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop

		if (!isset($key_value_pair[1]))

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $the_session_file_contents_array[$key] = $value;

    }





	foreach ($the_session_file_contents_array as $key => $i)

	{

		$_SESSION[$key] = $i;

	}



	set so knows user is logged in*/

	$_SESSION['logged_in'] = 1;

	$_SESSION['screen_name'] = $_POST['screen_name'];

	$_SESSION['password'] = $_POST['password'];

	

	echo "Welcome " . $_SESSION['screen_name'] . '.  <a href="build_resume.php">Continue.</a>';

	require("../buildsresumes.com/view/mid_google_ads.php");

	exit;	

}





/*Email address not recognized */

if (isset($_POST['email_address'])) {



	if (!file_exists($_POST['email_address'].".txt")) 

	die ("Unknown email address.  Cannot Sign-In.  <a href=\"sign_in.php\">Return.</a>");



}

require("../buildsresumes.com/view/mid_google_ads.php");

?>



	





<form action="sign_in.php" method="post">

<table width="300" border="0">

  <tr>

    <td valign="top">Username: &nbsp;</td>

    <td><input type="text" name="screen_name" /><br />&nbsp;</td>

  </tr>

  <tr>

    <td valign="top">Password: &nbsp;</td>

    <td><input type="password" name="password" />&nbsp;</td>

  </tr>

</table>







<br />

<a href="forgot_password.php">Forgot password</a><br />

<br />





<input type="submit" value="Login" /><input name="signing_in" type="hidden" value="1" /></form>

<br /><br />



<table ><tr><td>&nbsp;<img src="widgets/spacer.gif" height="5" width="225" alt=""></td><td><h3><a href="create_user.php">Create new account</a></h3></td></tr></table>

