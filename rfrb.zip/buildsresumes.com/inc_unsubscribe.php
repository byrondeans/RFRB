<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

require("../buildsresumes.com/top_inc_create_user.php"); ?>

<!-- BOF: ./personal-templates/show.body -->

<!-- BOF: ./personal-templates/simple/generic/show -->

<!-- BOF: ./personal-templates/rtl.html -->

<!-- Locale=en_US -->

<!-- EOF: ./personal-templates/rtl.html -->



<!-- BOF: ./personal-templates/simple/generic/functions -->

<!-- BOF: ./personal-templates/simple/generic/navbar -->



<!-- EOF: ./personal-templates/simple/generic/navbar -->





<!-- EOF: ./personal-templates/simple/generic/functions -->





<!-- EOF: ./personal-templates/simple/generic/show -->



<!-- BOF: ./personal-templates/simple/generic/images -->



<!-- EOF: ./personal-templates/simple/generic/images -->









<!-- BOF: ./personal-templates/simple/personal/other/l52.settings.init -->

























<!-- EOF: ./personal-templates/simple/personal/other/l52.settings.init -->





  

    <!-- BOF: ./personal-templates/simple/businessnew/amazon/style_l56.images -->

<!-- EOF: ./personal-templates/simple/businessnew/amazon/style_l56.images -->



    <!-- BOF: ./personal-templates/simple/businessnew/gpage/style_l56.wait -->





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  





<!-- EOF: ./personal-templates/simple/businessnew/gpage/style_l56.wait -->



  

  <!-- BOF: ./personal-templates/simple/businessnew/layout/l56.wait -->







 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  







 

 

  

  

  

    

  







 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  







 

 

  

  

  

    

  







 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  







 

 

  

  

  

    

  





























 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 





 

 

  

  

  

    

  







 

 

  

  

  

    

  







<!-- EOF: ./personal-templates/simple/businessnew/layout/l56.wait -->























  





  

<HTML>



<HEAD>





<META NAME="description" CONTENT="">

<META NAME="Keywords"    CONTENT="html, resume, cv, build, create, make, css">







<!-- business -->





<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">

<META NAME="Generator" content="">

<!-- BOF: ./personal-templates/simple/themes.show -->









<!-- EOF: ./personal-templates/simple/themes.show -->





<!--<BASE HREF="http://162.215.248.99/build_resume.php">-->

<TITLE>Resume Builder</TITLE></head>

<BODY  BGCOLOR="#FFFFFF"

 TEXT="#000000"



LEFTMARGIN="0" TOPMARGIN="0" RIGHTMARGIN="0" BOTTOMMARGIN="0"



 onLoad=""

 

 LINK="#000000"

 VLINK="#000000"

 ALINK="#926005"

>



  

    

      <!-- BOF: ./personal-templates/simple/businessnew/layout/l56.layout -->

<!-- html -->











<TABLE WIDTH="100%" HEIGHT="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

    <TR>

        <TD WIDTH=121 HEIGHT="100%" VALIGN="top">

            <TABLE WIDTH="100%" HEIGHT="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                <TR>

                    <TD WIDTH=121 HEIGHT=178 VALIGN="top">    

                        <img src="widgets/gen_11.1.gif" border=0 width=121 height=178 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH=121 HEIGHT=112 VALIGN="top">    

                        <img src="widgets/gen_12.1.gif" border=0 width=121 height=112 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH=121 HEIGHT=111 VALIGN="top">    

                        <img src="widgets/gen_13.1.gif" border=0 width=121 height=111 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH=121 HEIGHT=101 VALIGN="top">    

                        <img src="widgets/gen_14.1.gif" border=0 width=121 height=101 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH=121 HEIGHT="100%" BGCOLOR="#1C1A14" VALIGN="top">    

                        <img src="widgets/spacer.gif" height=6 width=6 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH=121 HEIGHT=198 VALIGN="top">    

                        <img src="widgets/gen_15.1.gif" border=0 width=121 height=198 alt=""></TD>

                </TR>

            </TABLE>

        </TD>

        <TD WIDTH=154 HEIGHT="100%" VALIGN="top">

            <TABLE WIDTH=154 HEIGHT="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                <TR>

                    <TD WIDTH=154 HEIGHT=168 VALIGN="top">

                        <img src="widgets/gen_16.1.gif" border=0 width=154 height=168 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH=154 VALIGN="top" >

                        

                        <a href="index.html" onMouseOver="document.images['img6'].src='widgets/gen_30.1.gif'" onMouseOut="document.images['img6'].src='widgets/gen_29.1.gif'"><img src="widgets/gen_29.1.gif" alt="Home" name="img6" border="0"></a><br>

                        <a href="build_resume.php" onMouseOver="document.images['img7'].src='widgets/gen_32.1.gif'" onMouseOut="document.images['img7'].src='widgets/gen_31.1.gif'"><img src="widgets/gen_31.1.gif" alt="Resume Builder" name="img7" border="0"></a><br>

                        <a href="advice_and_links.php" onMouseOver="document.images['img16'].src='widgets/gen_63.1.gif'" onMouseOut="document.images['img16'].src='widgets/gen_62.1.gif'"><img src="widgets/gen_62.1.gif" alt="Advice & Links" name="img16" border="0"></a><br>

                        <a href="contact_us.php" onMouseOver="document.images['img9'].src='widgets/gen_69.1.gif'" onMouseOut="document.images['img9'].src='widgets/gen_68.1.gif'"><img src="widgets/gen_68.1.gif" alt="Contact Us" name="img9" border="0"></a><br>

                        

                        

                        <a href="about.html" onMouseOver="document.images['img17'].src='widgets/gen_56.1.gif'" onMouseOut="document.images['img17'].src='widgets/gen_55.1.gif'"><img src="widgets/gen_55.1.gif" alt="About" name="img17" border="0"></a><br></TD>

                </TR>

                <TR>

                    <TD WIDTH=154 HEIGHT="100%" VALIGN="top" BACKGROUND="widgets/gen_17.1.gif">    

                        <img src="widgets/spacer.gif" height=6 width=6 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH=154 HEIGHT=23 VALIGN="top" BGCOLOR="#1C1A14">

                        <img src="widgets/gen_18.1.gif" border=0 width=154 height=23 alt=""></TD>

                </TR>

            </TABLE>

        <TD WIDTH="70%" HEIGHT="100%">

            <TABLE WIDTH="100%" HEIGHT="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                <TR>

                    <TD WIDTH="100%" HEIGHT=68 BGCOLOR="#1C1A14">

                        <img src="widgets/gen_19.1.gif" border=0 width=500 height=68 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH="100%" HEIGHT=28>

                        <TABLE WIDTH="100%" HEIGHT=28 BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                            <TR>

                                <TD WIDTH="100%" HEIGHT=28 BACKGROUND="widgets/gen_21.1.gif">

                                    <img src="widgets/gen_61.1.gif" border=0 width=500 height=28 alt=""></TD>

                                <TD WIDTH=14 HEIGHT=28>

                                    <img src="widgets/gen_22.1.gif" border=0 width=14 height=28 alt=""></TD>

                            </TR>

                        </TABLE>

                    </TD>

                </TR>

                <TR>

                    <TD WIDTH="100%" HEIGHT=170>

                        <TABLE WIDTH="100%" HEIGHT=170 BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                            <TR>

                                <TD WIDTH=30 HEIGHT=170>

                                    <img src="widgets/gen_23.1.gif" border=0 width=30 height=170 alt=""></TD>

                                <TD WIDTH="100%" HEIGHT=170 BACKGROUND="widgets/gen_25.1.gif">

                                    <img src="widgets/spacer.gif" height=6 width=6 alt=""></TD>

                                <TD WIDTH=470 HEIGHT=170 ALIGN="right">

                                    <img src="widgets/gen_9.1.gif" border=0 width=470 height=170 alt=""></TD>

                            </TR>

                        </TABLE>

                     </TD>

                </TR>

                <TR>

                    <TD WIDTH="100%" HEIGHT="100%">

                        <TABLE WIDTH="100%" HEIGHT="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                            <TR>

                                <TD WIDTH=9 HEIGHT=5 VALIGN="top" BGCOLOR="#1C1A14">    

                                    <img src="widgets/spacer.gif" height=5 width=9 alt=""></TD>

                                <TD WIDTH=5 HEIGHT=5 VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=5 width=5 alt=""></TD>

                                <TD WIDTH="100%" HEIGHT=5 VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=6 width=9 alt=""></TD>

                                <TD WIDTH=5 HEIGHT=5 VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=5 width=5 alt=""></TD>                                                

                                <TD WIDTH=9 HEIGHT=5 VALIGN="top" BGCOLOR="#1C1A14">    

                                    <img src="widgets/spacer.gif" height=5 width=9 alt=""></TD>

                            </TR>

                            <TR>

                                <TD WIDTH=9 HEIGHT="100%" VALIGN="top" BGCOLOR="#1C1A14">    

                                    <img src="widgets/spacer.gif" height=5 width=9 alt=""></TD>

                                <TD WIDTH=5 HEIGHT="100%" VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=5 width=5 alt=""></TD>

                                <TD WIDTH="100%" HEIGHT="100%" VALIGN="top" BGCOLOR="#D9D6D3">        

                                    <div align="justify">

                                    <!-- BOF: ./personal-templates/simple/businessnew/gpage/style_l56.html -->



            <TABLE WIDTH="100%" BORDER=0 CELLPADDING=0 CELLSPACING=0 VALIGN="top">

                <!--<TR>

                    <TD WIDTH="100%" valign="top" BACKGROUND="widgets/gen_36.1.gif">

                        <img src="widgets/spacer.gif" height=3 width=2 alt=""></TD>

                </TR>-->

                <TR>

                    <TD WIDTH="100%" valign="top">

                        <TABLE WIDTH="100%" BORDER=0 CELLPADDING=0 CELLSPACING=0 VALIGN="top">

                            <TR>

                                <TD valign="top">   

                                    <img src="widgets/gen_33.1.gif" border=0 width=453 height=45 alt=""></TD>

                                <TD WIDTH="100%" align="right" valign="top" BACKGROUND="widgets/gen_34.1.gif">

                                    <img src="widgets/gen_35.1.gif" border=0 width=20 height=45 alt=""></TD>

                            </TR>

                        </TABLE>

                    </TD>                                                

                </TR>

                <TR>

                    <TD WIDTH="100%" valign="top" BACKGROUND="widgets/gen_36.1.gif">

                        <img src="widgets/spacer.gif" height=3 width=2 alt=""></TD>

                </TR>

            </TABLE>



<TABLE WIDTH="100%" BORDER="0" VALIGN="top" CELLPADDING="0" CELLSPACING="0">

<br>

            

            

            

            

            

                

                

                

                           

                

    <TR>

        <TD WIDTH="100%" valign="top">

            

            

            <TABLE border="0" WIDTH="100%" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                <TR>

                

                         

                

                    <TD valign="top"  >

                        <TABLE border="0" WIDTH="100%" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                            <TR>

                                <TD>

            <TABLE WIDTH="100%" BORDER=0 CELLPADDING=0 CELLSPACING=0 VALIGN="top">

                <TR>

                    <TD WIDTH="100%" VALIGN="top" BGCOLOR="#D9D6D3">    

                        <TABLE BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                            <TR>

                                <TD COLSPAN="7" WIDTH="100%" valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>    

                            </TR>

                            <TR>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=4 alt=""></TD>    

                                <TD COLSPAN="5" WIDTH="100%" valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=4 alt=""></TD>                                            

                            </TR>

                            <TR>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>    

                                <TD WIDTH=3 valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD COLSPAN="3" WIDTH="100%" valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=3 valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>    

                            </TR>

                            <TR>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>

                                <TD WIDTH=3 valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=3 valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>        

                                <TD WIDTH="100%" VALIGN="top" BACKGROUND="widgets/gen_37.1.gif">





<p>

  

      <!-- BOF: ./personal-templates/simple/generic/paragraphs/style.1 -->

    <table width="100%" cellpadding="10" cellspacing="0" border="0">

      

      <tr>

    <td>&nbsp;</td><td>









<font face='Arial' size='2' color='#000000'>



	



<?php



$uid = $_GET['uid'];

$len = strlen($uid);



if(ctype_alnum($uid) && $len == 49) {

    

    $query = "SELECT `id`, `info` FROM `users` WHERE `user_id_encoded` = '" . $uid . "'";

    

    $mysqli = mysqli_connect("localhost", "bdeans10_GO108", "jfitzgerald", "bdeans10_users");

    

    $res = mysqli_query($mysqli, $query);

    

    $file_user_contents = "";

    $real_uid = 0;

    while ($i = mysqli_fetch_assoc($res)) {

    	$file_user_contents = $i['info'];

    	$real_uid = $i['id'];

    }

    

    $is_already_unsubscribed = strstr($file_user_contents, "offers_unsubscribe_time");

    

    if(!$is_already_unsubscribed) {

    	$present_time = time();

    	$remote_ip = $_SERVER['REMOTE_ADDR'];

    	$new_file_user_contents = $file_user_contents . "offers_unsubscribe_time=" . $present_time . ";;;" . "offers_unsubscribe_ip=" . $remote_ip . ";;;";

    	$query = "UPDATE `users` SET `info` = '$new_file_user_contents' WHERE `id` = " . $real_uid;

    	//$query = "UPDATE `users` SET `info` = '$new_file_user_contents' WHERE `id` = 5000";

    	$res = mysqli_query($mysqli, $query);

    	$affected_rows = mysqli_affected_rows($mysqli);

    	$email_contents = "Real uid: " . $real_uid . "  info contents: " . $file_user_contents;

    	

    	$file = "/home2/bdeans108ajd/buildsresumes.com/final-emailsforsite5-master.txt";

    	//$file = "/home2/bdeans108ajd/buildsresumes.com/testemailsforsite5.txt";

    	$f = fopen($file, 'r');

    	$i = 0;

    	$success = 0;

    	while($line = fgets($f)) {

    	    $array1 = explode(",", $line);

    	    

    	    $oversize_file_uid = $array1[4];

    	    $file_uid = substr($oversize_file_uid, 0, 49);

    	 

    	    if($file_uid == $uid){

    	        //print("The uid is in the file  and i is $i   ");

    	        read_and_delete_relevant_line($file, $i, $file_uid);

    	        $success = 1;

    	    }

    	    $i++;

    	    

    	}

    	if($affected_rows == 1 && $success){

        	if(mail('byrondeans@reallyfreeresumebuilder.com', "Someone unsubscribed", $email_contents)) {

        	    print("You have successfully unsubscribed.");

        	} else {

        	    print("Problem mailing the site admin about the unsubscribe.");

        	}

    	} else {

    	    if(mail('byrondeans@reallyfreeresumebuilder.com', "Someone had problem unsubscribing", $email_contents . " success is $success  and affected_rows is $affected_rows")) {

        	    print("Error unsubscribing.  Please try again later.");

        	} else {

        	    print("Problem mailing the site admin about the unsubscribe error.");

        	}

    	}

    } else {

        print("You are already unsubscribed.");

    }

} else {

    print("String is not entirely alphanumeric or is the wrong length.  If you're reading this, I'm looking for work, live with a yellow slip visa (allowing me to live and work permanently) and British citizenship in the Republic of Cyprus, and could use compassion and advice also.  I've been more or less based here since 2013 - Friday 31 Dec 2021.");

}



function read_and_delete_relevant_line($filename, $i, $encoded_uid) {

      $file = file($filename);

      $output = $file[$i];

      $success = 0;

      $contains_encoded_uid = strstr($output, $encoded_uid);

      if($contains_encoded_uid){

          unset($file[$i]);

          $success = 1;

      }

      file_put_contents($filename, $file);

      //print("in the read delete func ");

      return $success;

    }

?>



</font>





<br>



<br><!-- BOF buynow --><!-- EOF buynow -->

</td>

      </tr>

    </table>

<!-- EOF: ./personal-templates/simple/generic/paragraphs/style.1 -->



  

</p>



                                </TD>

                                <TD WIDTH=3 valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>        

                                <TD WIDTH=3 valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>    

                            </TR>

                            <TR>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>    

                                <TD WIDTH=3 valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD COLSPAN="3" WIDTH="100%" valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=3 valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>    

                            </TR>

                            <TR>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=4 alt=""></TD>    

                                <TD COLSPAN="5" WIDTH="100%" valign="top" BACKGROUND="widgets/gen_36.1.gif">

                                    <img src="widgets/spacer.gif" height=3 width=3 alt=""></TD>

                                <TD WIDTH=4 valign="top">

                                    <img src="widgets/spacer.gif" height=3 width=4 alt=""></TD>                                            

                            </TR>

                            <TR>

                                <TD COLSPAN="7" WIDTH="100%" valign="top">

                                    <img src="widgets/spacer.gif" height=4 width=4 alt=""></TD>    

                            </TR>

                        </TABLE>

                    </TD>

                </TR>

            </TABLE>

</TD>

                            </TR>

                        </TABLE>

                        

                    

                </TR>

            </TABLE>

            

        </TD>

        <TD VALIGN="TOP" background="">&nbsp;

            



</TD>

    </TR>

    <TR>

        <TD COLSPAN="2" background="" >

            <img src="widgets/spacer.gif" height=1 width=1 alt=""></TD>

    </TR>

    <TR>

        <TD COLSPAN=3 VALIGN="BOTTOM" ALIGN="CENTER">



</TD>

    </TR>

</TABLE>



<!-- EOF: ./personal-templates/simple/personalnew/gpage/style_l56.html -->



                                    

                                    <br>



<br>

<FONT FACE="verdana, arial, helvetica" SIZE="1">

<center>

<nobr>|<a href="index.html">Home</A>|</nobr>



<nobr>|Resume Builder|</nobr>



<nobr>|<a href="advice_and_links.php">Advice & Links</A>|</nobr>



<nobr>|<a href="contact_us.html">Contact Us</A>|</nobr>



<nobr>|<a href="about.html">About</A>|</nobr>

</center>

</font>



<br>

<center><table border="0" cellpadding="0" cellspacing="3"><tr><td align="center">



<br><font face="helvetica,verdana, arial" size="1">&nbsp;</font>



</td></tr></table></center>

<script language="javascript" src="widgets/noieactivate.js"></script>

</TD>

                                <TD WIDTH=5 HEIGHT="100%" VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=5 width=5 alt=""></TD>                                                

                                <TD WIDTH=9 HEIGHT="100%" VALIGN="top" BGCOLOR="#1C1A14">    

                                    <img src="widgets/spacer.gif" height=5 width=9 alt=""></TD>

                            </TR>

                            <TR>

                                <TD WIDTH=9 HEIGHT=5 VALIGN="top" BGCOLOR="#1C1A14">    

                                    <img src="widgets/spacer.gif" height=5 width=9 alt=""></TD>

                                <TD WIDTH=5 HEIGHT=5 VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=5 width=5 alt=""></TD>

                                <TD WIDTH="100%" HEIGHT=5 VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=6 width=9 alt=""></TD>

                                <TD WIDTH=5 HEIGHT=5 VALIGN="top" BGCOLOR="">    

                                    <img src="widgets/spacer.gif" height=5 width=5 alt=""></TD>                                                

                                <TD WIDTH=9 HEIGHT=5 VALIGN="top" BGCOLOR="#1C1A14">    

                                    <img src="widgets/spacer.gif" height=5 width=9 alt=""></TD>

                            </TR>

                            <TR>

                                <TD COLSPAN="5" WIDTH="100%" HEIGHT=8 VALIGN="top" BGCOLOR="#1C1A14">

                                    <img src="widgets/spacer.gif" height=8 width=9 alt=""></TD>

                            </TR>        

                        </TABLE>                        

                    </TD>

                </TR>

            </TABLE>

        </TD>

        <TD WIDTH="30%" HEIGHT="100%" VALIGN="top">

            <TABLE WIDTH="100%" HEIGHT="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0" VALIGN="top">

                <TR>

                    <TD WIDTH="100%" HEIGHT=381 BGCOLOR="#1C1A14" BACKGROUND="widgets/gen_26.1.gif" style="background-position: 100% 0%; background-repeat: no-repeat;">         

                        <img src="widgets/spacer.gif" height=381 width=1 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH="100%" HEIGHT="100%" BGCOLOR="#1C1A14" BACKGROUND="widgets/gen_27.1.gif" style="background-position: 100% 0%;">         

                        <img src="widgets/spacer.gif" height=1 width=1 alt=""></TD>

                </TR>

                <TR>

                    <TD WIDTH="100%" HEIGHT=381 BGCOLOR="#1C1A14" BACKGROUND="widgets/gen_28.1.gif" style="background-position: 100% 0%; background-repeat: no-repeat;">         

                        <img src="widgets/spacer.gif" height=381 width=1 alt=""></TD>

                </TR>

            </TABLE>

        </TD>

    </TR>

</TABLE>

<!-- end html -->

<!-- EOF: ./personal-templates/simple/businessnew/layout/l56.layout -->



    

  

   



<!-- BOF: ./personal-templates/simple/themes.show.body -->













<!-- EOF: ./personal-templates/simple/themes.show.body -->

<script type="text/javascript">

var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");

document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));

</script>

<script type="text/javascript">

var pageTracker = _gat._getTracker("UA-4842711-5");

pageTracker._initData();

pageTracker._trackPageview();

</script>

</body>

<!-- BOF: ./personal-templates/simple/themes.show.end -->

















<!-- EOF: ./personal-templates/simple/themes.show.end -->





  



</html>







<!-- EOF: ./personal-templates/show.body -->
