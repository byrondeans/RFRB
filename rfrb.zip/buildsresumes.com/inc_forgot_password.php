<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php 

require("../buildsresumes.com/view/css.php");

/* check if user clicked "forgot password" */









//****************************************

//****************************************SECTION1:  SEE IF USER FORGOT PASSWORD

//****************************************





if (isset($_GET['email_password'])) {



	if (isset($_POST['username'])) {





	require("../buildsresumes.com/database_access.php");

	//OLD mysql_select_db("bdeans10_users",$con);





	$screen_name = $_POST['username'];

	//OLD $result = mysql_query ("SELECT info, screen_name FROM users WHERE screen_name='$screen_name'");

    $query = "SELECT info, screen_name FROM users WHERE screen_name='$screen_name'";

    $result = mysqli_query($con, $query);

        

	$check = "";

	$info = "";

	/*check if username exists.  If it does, signal error.*/

	//while ($i = mysql_fetch_array($result)) {

    while ($i = mysqli_fetch_assoc($result)) {        

            $check = $i['screen_name'];

            if ($check == "")

            die("No account matches username " . $_POST['username'] . " <br />");



            if ($check != $_POST['username'])

            die ("Suspicious activity: " . $_POST['username'] . " does not equal username in database.");



            $info = $i['info'];

	}



    



    $info_array = explode (";;;", $info);

    $info_final_array = array("one" => "declared");



    	foreach ($info_array as $i) {

    	$key_value_pair = explode ("===", $i);



            /*if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop */

            if (!isset($key_value_pair[1]))

            break;



            $key = $key_value_pair[0];

            $value = $key_value_pair[1];

            $info_final_array[$key] = $value;

    	}    

    }

	    

    /* mail ($to, $subject, $message, $headers) */

	$email = $info_final_array['email1'];

    $password = $info_final_array['password1'];

	$message = "Here is your forgotten password.  Username: " . $screen_name . ".  Password: $password";

	$headers = "From: ReallyFreeResumeBuilder.com <noreply@reallyfreeresumebuilder.com>" . "\r\n";



        if(mail ($email,"ReallyFreeResumeBuilder.com: Your Password", $message, $headers)){



            echo "Sent password to " . $email . "<br />";

        } else {



            echo "Failed to send password.";

        }

        exit;

}

require("../buildsresumes.com/view/mid_google_ads.php");





echo "<form method=\"post\" action=\"forgot_password.php?email_password=1\">Enter username:

<input type=\"text\" name=\"username\" /><br /><input type=\"submit\" value=\"Send Password\" /></form>";



?>
