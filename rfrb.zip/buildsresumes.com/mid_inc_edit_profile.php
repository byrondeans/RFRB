<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->


<script type="text/javascript"><!--

google_ad_client = "pub-7032194388951945";

google_ad_width = 468;

google_ad_height = 60;

google_ad_format = "468x60_as";

google_ad_type = "text_image";

//2007-10-27: buildsresumes.usBldrTop1Left

google_ad_channel = "0235462580";

google_color_border = "000000";

google_color_bg = "F0F0F0";

google_color_link = "0000FF";

google_color_text = "000000";

google_color_url = "008000";

//-->

</script>

<script type="text/javascript"

  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">

</script>

<br /><br />

<?php

//require_once("../buildsresumes.com/view/mid_google_ads.php");



if(!isset($_SESSION['screen_name']))

die ("No user logged in, cannot edit cover letter.  <a href=\"sign_in.php\">Sign In</a> or <a href=\"create_user.php\">Create Account</a><br /><br /><br />");

else

echo "Welcome: " . $_SESSION['screen_name'] . " <a href=\"build_resume.php?sign_out=1\" >Sign Out</a><br /><br />";



//lookup screen_name.  Check password.

	$screen_name = $_SESSION['screen_name'];

	require("../buildsresumes.com/database_access.php");

	//OLD mysql_select_db("bdeans10_users",$con);







	

	$query = "SELECT info FROM users WHERE screen_name='" . $screen_name . "'";

	//$result = mysql_query($query);

	$result = mysqli_query($con, $query);



	$file_user_contents = "";

	while ($i = mysqli_fetch_assoc($result)) {

	$file_user_contents = $i['info'];

	}

	

	

	if ($file_user_contents == "")

	die ("Error, no data found in database for $screen_name");

	

	

	$fc_array = explode (";;;", $file_user_contents);

    $the_file_contents_array = array("one" => "declared");

    

    foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		/*if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop */

		if (!isset($key_value_pair[1]))

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $the_file_contents_array[$key] = $value;

    }

	/* double check that email_address.txt matches email_address contained inside */

	if ($screen_name != $the_file_contents_array['username'])

	die ("Wrong email");



    if ($_SESSION['password'] != $the_file_contents_array['password1'])

    die("Wrong password");









//OK, the username and password are correct.  Load cover letter into database and from database

	switch (isset($_POST['cover_letter'])) {	

	case FALSE:

	//if(!isset($_POST['cover_letter'])) {

		$query = "SELECT cover_letter FROM users WHERE screen_name='" . $screen_name . "'";

		//OLD $result = mysql_query($query);

        $result = mysqli_query($con, $query);

            

		$cover_letter_contents = "";

		while ($i = mysqli_fetch_assoc($result)) {

		$cover_letter_contents = $i['cover_letter'];

		}

	$GLOBALS['cover_letter'] = $cover_letter_contents;

	//}

	echo "Added your cover letter to form from database.";

	break;

	

	case TRUE:

	$GLOBALS['cover_letter'] = $_POST['cover_letter'];

	$cover_letter =	$_POST['cover_letter'];

	$query = "UPDATE users SET cover_letter='$cover_letter' WHERE screen_name='$screen_name'";

	//OLD mysql_query($query) 

//OLD or die(mysql_error()); 

    mysqli_query($con, $query);

	//make sure cover letter is available later in another section

	break;

	

	}

	

	

	//Update make_profile_public

	

	$query = "SELECT make_profile_public FROM users WHERE screen_name='" . $screen_name . "'";

	//OLD $result = mysql_query($query);

    mysqli_query($con, $query);

	$make_profile_public = 0;

		//OLD while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

         while ($i = mysqli_fetch_assoc($result)) {   

		$make_profile_public = $i['make_profile_public'];

		}

	

	

	

	if (!isset($_POST['make_profile_public']) && $make_profile_public == 1 && isset($_POST['coming_from']) && $_POST['coming_from'] == "edit_profile") {

	//turn off make_profile_public

		$query = "UPDATE users SET make_profile_public=0 WHERE screen_name='$screen_name'";

		//OLD mysql_query($query) 

		//OLD or die(mysql_error());

        mysqli_query($con, $query);

		$_SESSION['make_profile_public'] = 0;  

	}

	

	if (isset($_POST['make_profile_public']) && $make_profile_public == 0) {

	//turn on make_profile_public

		$query = "UPDATE users SET make_profile_public=1 WHERE screen_name='$screen_name'";

		//OLD mysql_query($query) 

		//OLD or die(mysql_error());

        mysqli_query($con, $query);

		$_SESSION['make_profile_public'] = 1; 

	}





	



//***************************** IMAGE CODE FOR VERIFYING AND MOVING IMAGE UPLOADS

//***************************** 

//***************************** 

if(isset($_POST['just_uploaded_a_file'])) {

	$uploaddir = 'uploads/';

	$uploadfile = $uploaddir . $screen_name . ".jpg";



	echo '<pre>';

	

	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {

    echo "File is valid, and was successfully uploaded.\n";

	} else {

    echo "Possible file upload attack!\n  Your image must be less that 125 kilobytes and must be a .jpg (jpeg or pjpeg)";

	}



	echo 'Here is some more debugging info:';

	print_r($_FILES);

	

	print "</pre>";

	

}





	





?>





<form action="edit_profile.php" method="post">

<input name="coming_from" type="hidden" value="edit_profile">

<?php

	//write checkbox for make_profile_public

	echo "Make Profile Public <input name=\"make_profile_public\" type=\"checkbox\" value=\"1\"";



	if($_SESSION['make_profile_public'] == 1)

	echo "checked"; 

	

	echo " />&nbsp;";

	

		//write the view profile link

	if($_SERVER['HTTP_HOST'] == "localhost")

	$domain_name = "";

	else

	$domain_name = "http://" . $_SERVER['HTTP_HOST'] . "/";

	

	if($_SESSION['make_profile_public'] == 1)

	echo "<br />Your profile page can now be seen at: <br /><a href=\"$domain_name"."profile.php?profile_for=$screen_name\">$domain_name"."profile.php?profile_for=$screen_name</a><br />";

	echo "<input type=\"submit\" action=\"edit_profile.php\" value=\"Update\" /><br />";



?>

<br />

Add your cover letter here: <br />

<textarea name="cover_letter" cols="50" rows="30"><?php echo $GLOBALS['cover_letter'] ?></textarea>

<br />



<input type="submit" value="Save Cover Letter" />





</form>

<br />

<?php

/*      Removed ability to upload photo

<!-- The data encoding type, enctype, MUST be specified as below -->

<form enctype="multipart/form-data" action="edit_profile.php" method="POST">

    <!-- MAX_FILE_SIZE must precede the file input field -->

    <input type="hidden" name="MAX_FILE_SIZE" value="150000" />

    <!-- Name of input element determines name in $_FILES array -->

    Send image of self: <input name="userfile" type="file" />

    <input type="hidden" name="just_uploaded_a_file" value="1" />

    <input type="submit" value="Send File" />

</form>



*/?>

<?php

	if(file_exists("../uploads/$screen_name" . ".jpg"))

	echo "<br />This photo will be displayed on with your cover letter and resume.<br /> <img src=\"uploads/$screen_name" . ".jpg\" /> ";



        /*  Removed ability to upload photo but not to display

        else

	echo "No image on server."

         * */



?>

</body>

</html>
