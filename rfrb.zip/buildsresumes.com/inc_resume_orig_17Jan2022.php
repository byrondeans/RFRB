<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

if(isset($_GET['force_download'])) {

header('Content-Type: application/octet-stream'); 

header('Content-Disposition: attachment; ' . 'filename="resume.html"');

header("Content-Type: application/force-download");

}

if(isset($_GET['view_contact_information']))

die("You may view the contact information you have purchased at any time in your Google Checkout purchase history.");



if(isset($_GET['resume_for'])) {



	$screen_name = $_GET['resume_for'];

	//$con -= mysql_connect("localhost", "bdeans10_GO108", "jfitzgerald");

	//$con -= mysql_connect("localhost", "root", "");

	require("database_access.php");

	mysql_select_db("bdeans10_users",$con);

	//$screen_name = $_POST['screen_name'];

	

	

	$query = "SELECT make_profile_public, session FROM users WHERE screen_name='$screen_name'";

	$result = mysql_query($query);

	

	

	$make_profile_public = 0;

	$session_contents = "";

	while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

	

		$make_profile_public = $i['make_profile_public'];

		$session_contents = $i['session'];

	}

	

	

	if ($session_contents == "")

		die ("Error, no data found in database for $screen_name");

	

	if($make_profile_public != 1)

		die ("This resume is not available for public viewing.");

	

	$fc_array = explode (";;;", $session_contents);

    $_SESSION = array("one" => "declared");

    

    foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		/*if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop */

		if (!isset($key_value_pair[1]))

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $_SESSION[$key] = $value;

    }

} 



elseif (isset($_GET['contact_info_forsale'])) 

{

	require_once("database_access.php");

	require_once("model/explode_associative_array.php");

	mysql_select_db("bdeans10_users");

	$_SESSION = array("one" => "declared");

	

	if(isset($_GET['with_account'])) {

		$id = $_GET['with_account'];

		settype($id, integer);

		$_SESSION['id'] = $_GET['with_account'] . "_with_account";

		$query = "SELECT session FROM `users` WHERE id=$id";

		$result = mysql_query($query) or die(mysql_error());

		$item_name = "Contact_Information_for_$id_with_account";

		while($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

			$session = $i['session'];

			$_SESSION = explode_associative_array($session);

		}

	}

	if(isset($_GET['without_account'])) {

		$id = $_GET['without_account'];

		settype($id, integer);

		$_SESSION['id'] = $_GET['without_account'] . "_without_account";

		$query = "SELECT session_data FROM `stored_sessions` WHERE id=$id";

		$result = mysql_query($query) or die(mysql_error());

		$item_name = "Contact_Information_for_$id_without_account";

		while($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

			$session_data = $i['session_data'];

			$_SESSION = explode_associative_array($session_data);

		}

	}

    require("model/prices.php");



	$_SESSION['secret_name'] = $_SESSION['name'];

	$_SESSION['secret_phone'] = $_SESSION['phone'];

	$_SESSION['secret_address_line_1'] = $_SESSION['address_line_1'];

	$_SESSION['secret_address_line_2'] = $_SESSION['address_line_2'];

	$_SESSION['secret_email'] = $_SESSION['email'];

	$_SESSION['name'] = "Contact Information for Resume Only $$basic_contact_information_price";

	$_SESSION['phone'] = "Phone: Buy Now";

	$_SESSION['address_line_1'] = "Address 1: Buy Now";

	$_SESSION['address_line_2'] = "Address 2: Buy Now";

	$_SESSION['email'] = "<a href=\"browse_resumes.php\">Back to " . $_SERVER['HTTP_HOST'] . "</a>";

	/*$with_account = "with_account";

	$without_account = "without_account";

	if($_SESSION['name'] != "")

	$_SESSION['name'] = "<a href=\"purchase_contact_information.php?id_with_account=$_GET[$with_account]&id_without_account=$_GET[$without_account]\">Name: Purchase</a>";*/

/*

	if($_SESSION['phone'] != "")

	$_SESSION['phone'] = "<a href=\"purchase_contact_information.php?id_with_account=$_GET['with_account']&id_without_account=$_GET['without_account']\">Phone: Purchase</a>";

	

	if($_SESSION['email'] != "")

	$_SESSION['email'] = "<a href=\"purchase_contact_information.php?id_with_account=$_GET['with_account']&id_without_account=$_GET['without_account']\">email: Purchase</a>";

	

	if($_SESSION['address_line_1'] != "")

	$_SESSION['address_line_1'] = "<a href=\"purchase_contact_information.php?id_with_account=$_GET['with_account']&id_without_account=$_GET['without_account']\">address_line_1: Purchase</a>";

	

	if($_SESSION['address_line_2'] != "")

	$_SESSION['address_line_2'] = "<a href=\"purchase_contact_information.php?id_with_account=$_GET['with_account']&id_without_account=$_GET['without_account']\">address_line_2: Purchase</a>";

*/

}

else

session_start();

//Now begin normal display for logged in user.

?>









<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"

        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<!-- This resume was created using the <?php echo $_SERVER['HTTP_HOST']; ?> web application available at <?php echo "<http://" . $_SERVER['HTTP_HOST']; ?>-->

<html>

<head>

<title><?php if(!isset($_GET['contact_info_forsale'])) echo $_SESSION['name'] . "'s Resume";

else echo "Contact Information FOR SALE: Buy Now"; ?></title>

<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<style type="text/css" media="all">

/*	Body

------------------------------------------------------*/



body {

	margin: 0;

	padding: 0;

	font-size: 62.5%;

	font-family: Verdana, Helvetica, "Bitstream Vera Sans", sans-serif;

	}



p 	{

	font-size: 1.2em;

	padding: 0;

	margin: 0 0 .25em 0; 

	}

	

a:link, a:visited {

	color: #080052;

	text-decoration: none;

	}



a:hover, a:active {

	color: #080052;

	text-decoration: none;

	border-bottom: 1px dotted #080052;

	}

	



h1 	{ /* name */

	margin: 0px 0px 5px; 

	font: bold 1.8em Georgia, serif;

	}

	

h2 	{ /* module titles */

	padding: 0;

	margin: .1em 0 .5em 0; 

	font-family: Georgia, serif;

	font-weight: bold;

	font-size: 1.2em; 

	text-transform: uppercase;

	}

	

h3 	{	/* job titles */

	padding: 0;

	float: left; 

	margin: 0; 

	font: bold 1.2em verdana, arial, helvetica, sans-serif;  	

	}

	

li 	{

	padding: 0;

	margin: 0 0 3px 2.5em; 

	font-size: 1.2em; 	

	}

	

body ul {

	padding: 0;

	margin: 0; 

	}

	

body div ul {

	padding: 0;

	margin: 3 0 0 0; 

	}



/*	IDs: (Page Structure)

------------------------------------------------------*/	



#container {

	width: 75em;

	margin: 10px 2.5em; 

	text-align: left;

	overflow: hidden;

	}



#header {	/* obviously, change this name if you already have a header for the site */

	width: 70em;	

	margin: 0;

	padding: 0;

	overflow: visible;

	}

	

#name {

	float: left;

	width: 45em;

	margin: 0;

	padding: 0;

	}

	

#contact_info	{

	float: left;

	width: 25em;

	margin: 0;

	padding: 0;

	}

	

	

/*	Classes, A-Z

------------------------------------------------------*/





.chron_meta	{

	width: 71em;

	}

	

.chron_module {		

	clear: both; 

	width: 71em;	 

	}

	

.company {

	float: left;

	padding: 0;

	margin: 0;

	width: 30em;

	}		

	

.data {

	clear: both;

	padding-left: 2.5em;

	}



.date {

	float: left;

	width: 7em;

	padding-top: 0;

        padding-right: 1em;

	}

	

.education {

	float: left;

	width: 20em;

	text-align: right;

	}

	

.functional_exp	{

	padding: 0;

	margin: 1.5em 0 .5em 0;

	font-size: 1.1em;

	font-style: italic;

	font-weight: bold;

	}



.job_details	{

	clear: both;

	position: relative;

	left: 12em;

	width: 59em;

	}

	

.location {

	float: left; 

	width: 20em; 

	text-align: right;

	}	

	

.position {

	margin: 0 0 .25em 0;

	padding: 0;

	font-style: italic;

	}

	

div.meta_module {

	clear: both;

	width: 70em;

	margin: 2em 0 0 0;

	padding: .5em 0 0 0;

	border-top: 1px solid black;

	}		



</style>





</head>



<BODY>

<div id="container">

	<div id="header">

		<div id="name">

			<H1><?php echo $_SESSION['name']; ?></H1>

		</div>

		<div id="contact_info">

			<!-- removed classes here and made one P for each: address, phone(s), email --> 

			<P><?php echo $_SESSION['address_line_1']; ?><BR><?php echo $_SESSION['address_line_2']; ?></P>

			<p><?php echo $_SESSION['phone']; ?></p> 

			<P><?php echo $_SESSION['email']; ?></P>

		</div>

		<br style="clear:both"/>

	</div>



<?php



if(isset($_GET['contact_info_forsale'])) {

  require_once('../library/googlecart.php');

  require_once('../library/googleitem.php');

  require_once('../library/googleshipping.php');

  require_once('../library/googletax.php');



  function Usecase() {

      require("model/prices.php");

	  echo "<h2>Contact Information for Sale: $$basic_contact_information_price</h2>";

      $merchant_id = "875164446602721";  // Your Merchant ID

      $merchant_key = "3rZNmdJBu1ujBPfkgZO3iA";  // Your Merchant Key

      //$server_type = "sandbox";

	  $server_type = "production";

      $currency = "USD";

      $cart = new GoogleCart($merchant_id, $merchant_key, $server_type,

      $currency);

      $total_count = 1;

	  $price = $basic_contact_information_price;

      $item_1 = new GoogleItem("Contact Information",      // Item name

                               "Telephone number, email address and mailing address for the resume you have selected.", // Item      description

                               $total_count, // Quantity

                               $price); // Unit price



  $return_to_link = $_SERVER['HTTP_HOST'];//http://example.com/download.php?id=15    S/N: 123.123123-3213 

  //<![CDATA[....put text containg markup here...]]> <br />

  //Get the users personal information.



	//$screen_name = $_POST['screen_name'];

	

	

  $contact_information = "Name: " . $_SESSION['secret_name'] . " Phone: " . $_SESSION['secret_phone'] . " Email address: " . $_SESSION['secret_email'] . " Mailing address line 1: " . $_SESSION['secret_address_line_1'] . "Mailing address line 2: " . $_SESSION['secret_address_line_2'] . " ";

  //<![CDATA[<br />]]>

  $id = $_SESSION['id'];

  $item_1->SetURLDigitalContent('http://' . $return_to_link . '/resume.php?view_contact_information=$id',

                                '',

                                "The Contact Information for the Resume You Were Looking At - $contact_information");





	  $cart->AddItem($item_1);

      

      // Add tax rules

      $tax_rule = new GoogleDefaultTaxRule(0.05);

      $tax_rule->SetStateAreas(array("IA"));

      $cart->AddDefaultTaxRules($tax_rule);

      

      // Specify <edit-cart-url>

      //$cart->SetEditCartUrl("https://www.example.com/cart/");

      

      // Specify "Return to xyz" link

      $return_to_link = $_SERVER['HTTP_HOST'];

      $cart->SetContinueShoppingUrl("http://" . $return_to_link . "/browse_resumes.php");

      

      // Request buyer's phone number

      $cart->SetRequestBuyerPhone(true);

      

      // Display Google Checkout button

      echo $cart->CheckoutButtonCode("SMALL");

  }



usecase();

echo "<h6>Use of this site is subject to <a href=\"terms_of_use.php\">Terms &amp; Conditions of Use</a>.  It is against site policy to sell, transmit or post contact information purchased on this site.</h6>";

}

?>



	<div class="meta_module">

		<H2>OBJECTIVE</H2>

		<P class="data"><?php echo $_SESSION['objective']; ?></P>

	</div>

	<div class="meta_module">

		<H2>EXPERIENCE</H2>



<?php

for ($i = 1; $i <= $_SESSION['number_employer'];$i++)

{

	$employer_name = "employer" . $i . "_name";

	$employer_dates = "employer" . $i . "_dates";

	$employer_type = "employer" . $i . "_type";

	$employer_location = "employer" . $i . "_location";

	$employer_url = "employer" . $i . "_url";

	$job_title = "employer" . $i . "_job_title";

?>

			<DIV class="chron_module">

				<DIV class="chron_meta">

					<P class="date"><?php echo $_SESSION[$employer_dates]; ?></P>

					<H3 class="company"><?php if ($_SESSION[$employer_url] != ""){

					echo '<A href="' . $_SESSION[$employer_url] . '">' . $_SESSION[$employer_name] . '</A>';}

					else {

					echo $_SESSION[$employer_name]; } ?></H3>





					<P class="location"><?php echo $_SESSION[$employer_location]; ?></P>

				</DIV>	

				<div class="job_details">

					<P class="position"><?php echo $_SESSION[$job_title]; ?></P>

					<UL>

					<?php

						$number_accomplishments = "employer" . $i . "_number_accomplishments";

						for ($j = 1;$j <= $_SESSION[$number_accomplishments];$j++)

						{

							$employer_i_accomplishmentj = "employer$i" . "_accomplishment$j";

					?>

						<LI><?php echo $_SESSION[$employer_i_accomplishmentj]; ?>

					<?php } ?>

					</UL>&nbsp; 

		  		</div>

			</DIV>

<?php } //end foreach ?>

				

	</div>

	

	<div class="meta_module">

		<H2>PROJECTS AND SKILLS</H2>

		<div class="data">

			<UL>

			<?php 

			for ($i = 1; $i <= $_SESSION['number_skills'];$i++)

			{

				$skill = "skill$i";

			?>

  				<LI><?php echo $_SESSION[$skill]; ?></LI>

  			<?php } ?>	

  			</UL>

		</div>

	</div>

	<div class="meta_module">

		<H2>EDUCATION</H2>

		<div class="data">

			<UL>

			<?php 

			for ($i = 1; $i <= $_SESSION['number_education'];$i++)

			{

				$education = "education$i";

			?>

  				<LI><?php echo $_SESSION[$education]; ?></LI>

  			<?php } ?>	

  			</UL>

		</div>

	</div>

<?php /*

	<div class="meta_module">

		<H2>INTERESTS &amp; HOBBIES</H2>

		<div class="data">

			<UL>

			<?php 

			for ($i = 1; $i <= $_SESSION['number_interest'];$i++)

			{

				$interest = "interest$i";

			?>

  				<LI><?php echo $_SESSION[$interest]; ?></LI>

  			<?php } ?>	

  			</UL>

		</div>

	</div>

 *

 */ ?>

<script type="text/javascript">

var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");

document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));

</script>

<script type="text/javascript">

var pageTracker = _gat._getTracker("UA-4842711-5");

pageTracker._initData();

pageTracker._trackPageview();

</script>

</body>

</html>

