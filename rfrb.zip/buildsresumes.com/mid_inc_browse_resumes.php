<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php 

	$security_code = $_GET['security_code'];

        

        if($security_code != 'EaHEuaUHRHVLCF8211Op') {

            die('invalid security code');

        }





        if(isset($_GET['start'])) {

		$start = $_GET['start'];

		settype($start, integer);

	}

	else

	$start = 0;



	require_once("model/explode_associative_array.php");

	require("database_access.php");

	mysql_select_db("bdeans10_users",$con);



        $query = "SELECT last_updated, id, session FROM `users` ORDER BY last_updated DESC";

	$result = mysql_query($query) or die(mysql_error());



        while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

		$id = $i['id'];

		$last_updated = $i['last_updated'];

		$session = $i['session'];

		$last_updated_h = date("j M Y h:i:s a", $last_updated);

		

		$assoc_array_exploded = explode_associative_array($session);

		$objective = $assoc_array_exploded['objective'];

		echo "Last Updated: $last_updated_h  &nbsp;<a href=\"resume.php?contact_info_forsale=1&with_account=$id\">Resume</a>&nbsp;Objective: $objective <br />";

	}



	echo "<br /><br /><h2>Resumes created without account setup</h2>";



	$query = "SELECT last_updated, id, session_data FROM `stored_sessions` ORDER BY last_updated DESC";

	$result = mysql_query($query) or die(mysql_error());	



	while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

		$id = $i['id'];

		$last_updated = $i['last_updated'];

		$session = $i['session_data'];

		$last_updated_h = date("j M Y h:i:s a", $last_updated);



		$assoc_array_exploded = explode_associative_array($session);

		$objective = $assoc_array_exploded['objective'];

		echo "Last Updated: $last_updated_h  &nbsp;<a href=\"resume.php?contact_info_forsale=1&without_account=$id\">Resume</a>&nbsp;Objective: $objective <br />";

	}



?>
