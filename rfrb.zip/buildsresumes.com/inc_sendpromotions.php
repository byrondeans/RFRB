<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

$file = "/home2/bdeans108ajd/buildsresumes.com/final-emailsforsite5.txt";

//$file = "/home2/bdeans108ajd/buildsresumes.com/testemailsforsite5.txt";

$f = fopen($file, 'r');

$line = fgets($f);



$array1 = explode(",", $line);



fclose($f);



if(isset($array1[3])){

    $file2 = "/home2/bdeans108ajd/buildsresumes.com/final-promotion.txt";

    $msg = file_get_contents($file2);

    

    

    $name = $array1[3];

    $second_to_final_msg = str_replace("[1]", $name, $msg);

    

    $user_id_encoded = $array1[4];

    $user_id_encoded = substr($user_id_encoded, 0, 49);

    $unsubscribe_link = "http://reallyfreeresumebuilder.com/unsubscribe.php?uid=$user_id_encoded";

    

    $final_msg = str_replace("[2]", $unsubscribe_link, $second_to_final_msg) ;

    $final_msg = wordwrap($final_msg, 70);

    

    $email = $array1[2];

    

    $headers = 'Bcc: byrondeans@reallyfreeresumebuilder.com' . "\r\n" . 

        'From: Byron Deans' . "\r\n" .

       'Reply-To: byrondeans@reallyfreeresumebuilder.com' . "\r\n" .

       'MIME-Version: 1.0' . "\r\n" .

       'Content-type:text/html' . "\r\n";

    

    $mysqli = mysqli_connect("localhost", "bdeans10_GO108", "jfitzgerald", "bdeans10_users");

    

    $headers_test = 'From: Byron Deans' . "\r\n" .

       'Reply-To: byrondeans@reallyfreeresumebuilder.com' . "\r\n";

    

    $email_test = "byrondeans@reallyfreeresumebuilder.com"; // for testing purposes only

    //$email = $email_test;

    

    $query = "SELECT `id`, `info` FROM `users` WHERE `user_id_encoded` = '$user_id_encoded';";

    $res = mysqli_query($mysqli, $query);



    while ($i = mysqli_fetch_assoc($res)) {

        $db_uid = $i['id'];

        $file_uid = $array1[1];

        if($db_uid == $file_uid){

            $real_uid = $db_uid;

            

            $query3 = "SELECT `id`, `info` FROM `users` WHERE `user_id_encoded` = '" . $user_id_encoded . "'";

    

            $res3 = mysqli_query($mysqli, $query);

    

            $file_user_contents = "";

            $real_uid = 0;

            while ($i = mysqli_fetch_assoc($res3)) {

    	        $file_user_contents = $i['info'];

            }



            $is_already_unsubscribed = strstr($file_user_contents, "offers_unsubscribe_time");

            $user_id_encoded_half = substr($user_id_encoded, 0, 25);

            if(!$is_already_unsubscribed) {

                if(mail($email, "Free Advice and an Offer From ReallyFreeResumebuilder.com", $final_msg, $headers)) {

                		$file_user_contents = $i['info'];

                		$present_time = time();

                		$updated_file_user_contents = $file_user_contents . "emailcampaign2senttime=" . $present_time . ";;;";

                		$updatequery = "UPDATE `users` SET `info` = '" . $updated_file_user_contents . "' WHERE `id` = " . $real_uid;

                		$res2 = mysqli_query($mysqli, $updatequery);

                		//print("Sent " . $array1[2] . "an email at $present_time.");

                		print("Sent user_id_encoded snippet " . $user_id_encoded_half . " an email.");

                } else {

                	print("Mail failed");

                }

            

            } else {

                print("Already unsubscribed $user_id_encoded_half");

            }

        } else {

            print("db_uid doesn't match file_uid for db_uid $db_uid and file_uid $file_uid");

        }

    }

    

    function read_and_delete_first_line($filename) {

      $file = file($filename);

      $output = $file[0];

      unset($file[0]);

      file_put_contents($filename, $file);

      return $output;

    }

    

    read_and_delete_first_line($file);

} else {

    $time = time();

    print("Reached the end of the file " . $time . "\r\n");

}





?>

