<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

$user_to_display = $_GET['profile_for'];

	

if($user_to_display == "")

die ("No user to display.");



	require("../buildsresumes.com/database_access.php");

	//OLD mysql_select_db("bdeans10_users",$con);

	$screen_name = $_SESSION['screen_name'];

	

	

	$query = "SELECT info FROM users WHERE screen_name='" . $user_to_display . "'";

	//OLD $result = mysql_query($query);

    $result = mysqli_query($con, $query);

	

	$file_user_contents = "";

	//OLD while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

    while ($i = mysqli_fetch_assoc($result)) {  

	$file_user_contents = $i['info'];

	}



if ($file_user_contents == "")

	die ("Error, no data found in database for $screen_name");

	

/*

	$fc_array = explode (";;;", $file_user_contents);

    $the_file_contents_array = array("one" => "declared");

    

    foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		//if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop

		if (!isset($key_value_pair[1]))

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $the_file_contents_array[$key] = $value;

    }



*/





//if($_SESSION['screen_name'] != $the_file_contents_array[''] == 0)

//die ("This user does not allow a public profile page.");





//GET COVER LETTER and MAKE_PROFILE_PUBLIC from database

$query = "SELECT cover_letter FROM users WHERE screen_name='" . $user_to_display . "'";

//OLD $result = mysql_query($query);

$result = mysqli_query($con, $query);



	$cover_letter_contents = "";

	//OLD while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

    while ($i = mysqli_fetch_assoc($result)) {

	$cover_letter_contents = $i['cover_letter'];

	}







	$query = "SELECT make_profile_public FROM users WHERE screen_name='" . $user_to_display . "'";

	//OLD $result = mysql_query($query);

	$result = mysqli_query($con, $query);

    

	$make_profile_public = 0;

	//OLD while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

    while ($i = mysqli_fetch_assoc($result)) {

	$make_profile_public = $i['make_profile_public'];

	}



	if($make_profile_public == 0)

	die ("Not available for public viewing.");



echo "<a href=\"resume.php?resume_for=$user_to_display \">View resume</a> <br /><br />";

if(file_exists("uploads/" . $user_to_display . ".jpg"))

echo "<img src=\"uploads/" . $user_to_display . ".jpg\" align=\"left\" />";



echo $cover_letter_contents;

?>

