<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php 



require("top_inc_create_user.php");



?>



<!-- BOF: ./personal-templates/simple/personal/custom/custom.show.body -->



<!-- BOF: ./personal-templates/simple/generic/functions -->

<!-- BOF: ./personal-templates/simple/generic/navbar -->



<!-- EOF: ./personal-templates/simple/generic/navbar -->





<!-- EOF: ./personal-templates/simple/generic/functions -->





 <!-- BOF: ./personal-templates/show.body -->

<!-- BOF: ./personal-templates/simple/generic/show -->

<!-- BOF: ./personal-templates/rtl.html -->

<!-- Locale=en_US -->

<!-- EOF: ./personal-templates/rtl.html -->



<!-- BOF: ./personal-templates/simple/generic/functions -->

<!-- BOF: ./personal-templates/simple/generic/navbar -->



<!-- EOF: ./personal-templates/simple/generic/navbar -->





<!-- EOF: ./personal-templates/simple/generic/functions -->





<!-- EOF: ./personal-templates/simple/generic/show -->



<!-- BOF: ./personal-templates/simple/generic/images -->



<!-- EOF: ./personal-templates/simple/generic/images -->









<!-- BOF: ./personal-templates/simple/personal/other/l68.settings.init -->

























<!-- EOF: ./personal-templates/simple/personal/other/l68.settings.init -->





  

    <!-- BOF: ./personal-templates/simple/businessnew/custom/style_l68.images -->

<!-- EOF: ./personal-templates/simple/businessnew/custom/style_l68.images -->



    <!-- BOF: ./personal-templates/simple/businessnew/custom/style_l68.wait -->



 

 

  

  

  

    

  











 

 

  

  

  

    

  







 

 

  

  

  

    

  







<!-- EOF: ./personal-templates/simple/businessnew/custom/style_l68.wait -->



  

  <!-- BOF: ./personal-templates/simple/business/layout/l68.wait -->





 

 

  

  

  

    

  











 

 

  

  

  

    

  







 

 

  

  

  

    

  







 

 

  

  

  

    

  









 

 

  

  

  

    

  







 

 

  

  

  

    

  







 

 

  

  

  

    

  







 

 

  

  

  

    

  

 





 

 

  

  

  

    

  

 

















<!-- EOF: ./personal-templates/simple/business/layout/l68.wait -->























  





  

<HTML>



<HEAD>





<META NAME="description" CONTENT="Builds professional resumes.  FREE FROM START TO FINISH">

<META NAME="Keywords"    CONTENT="resume, cv, builder, creater, creator, template, advice, tips">







<!-- business -->





<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">

<META NAME="Generator" content="">

<!-- BOF: ./personal-templates/simple/themes.show -->









<!-- EOF: ./personal-templates/simple/themes.show -->





<!--<BASE HREF="http://162.215.248.99/build_resume.php.html">-->

<TITLE>Build Resume</TITLE></head>

<BODY  BGCOLOR="#FFFFFF"

 TEXT="#333333"



LEFTMARGIN="0" TOPMARGIN="0" RIGHTMARGIN="0" BOTTOMMARGIN="0"



 onLoad=""

 

 LINK="#CC0000"

 VLINK="#990000"

 ALINK="#990000"

>



  

    

      <!-- BOF: ./personal-templates/simple/business/layout/l68.layout --> 

<TABLE WIDTH="100%" height="100%" BORDER=0 CELLPADDING=0 CELLSPACING=0 valign="top" bgcolor="#990000" background="widgets/gen_3.1.gif">

  <TR>

     <TD width="720">

         <TABLE WIDTH="720" height="100%" BORDER=0 CELLPADDING=0 CELLSPACING=0 valign="top" bgcolor="#FFFFFF">

            <TR>

               <TD rowspan="6"><img src="widgets/spacer.gif" height=5 width=10 alt=""></TD>

               <TD colspan="3"><img src="widgets/gen_7.1.gif" border=0 height=31 alt=""><br><img src="widgets/gen_8.1.gif" border=0 height=19 alt=""><br></TD>

            </TR>

            <tr><td colspan="3" height="8" background="widgets/gen_6.1.gif" style="background-repeat: repeat-x;"><img src="widgets/spacer.gif" height=8 width=3 alt=""></td></tr>

            <tr><td colspan="3"><img src="widgets/spacer.gif" height=10 width=3 alt=""></td></tr>

            <TR>

               <TD WIDTH="250" height="100%" valign="top"><TABLE WIDTH="250" height="100%" BORDER=0 CELLPADDING=0 CELLSPACING=0 valign="top">

                            <TR><TD>

                                 <TABLE WIDTH="250" BORDER=0 CELLPADDING=0 CELLSPACING=0 valign="top">

                                    <tr>

                                       <td rowspan="3" bgcolor="#CC0000" width="3"><img src="widgets/spacer.gif" height=5 width=3 alt=""></td>

                                       <td height="1" bgcolor="#660000"><img src="widgets/spacer.gif" height=1 width=1 alt=""></td>

                                       <td width="1" rowspan="3" bgcolor="#660000"><img src="widgets/spacer.gif" height=1 width=1 alt=""></td>

                                       <td rowspan="3" background="widgets/gen_10.1.gif" style="background-repeat: no-repeat;background-position:left top;"><img src="widgets/spacer.gif" height=129 width=22 alt=""></td>

                                    </tr>

                                    <tr><td bgcolor="#990000" background="widgets/gen_4.1.gif" style="background-repeat: repeat-x ;background-position:left top;">

                                  <TABLE BORDER=0 CELLPADDING=10 CELLSPACING=0 valign="top"><tr><td><img src="widgets/spacer.gif" height=106 width=1 alt=""></td></tr></table></td></tr>

                                    <tr><td height="1" bgcolor="#660000"><img src="widgets/spacer.gif" height=1 width=1 alt=""></td></tr>

                                 </TABLE>

                            </TD></TR>

                            <TR><TD valign="top" height="100%" width="220">

                                            

                                            

                                            

                                            <a href="index.php" onMouseOver="document.images['img6'].src='widgets/gen_13.1.gif'" onMouseOut="document.images['img6'].src='widgets/gen_12.1.gif'"><img src="widgets/gen_12.1.gif" alt="Home" name="img6" border="0"></a><br>

                                            <a href="build_resume.php" onMouseOver="document.images['img8'].src='widgets/gen_23.1.gif'" onMouseOut="document.images['img8'].src='widgets/gen_22.1.gif'"><img src="widgets/gen_22.1.gif" alt="Build Resume" name="img8" border="0"></a><br><a href="mailto:deans_ab@yahoo.com" onMouseOver="document.images['img_email'].src='widgets/gen_15.1.gif'" onMouseOut="document.images['img_email'].src='widgets/gen_14.1.gif'"><img src="widgets/gen_14.1.gif" alt="e-mail me" name="img_email" border="0"></a><br>

                            </td></TR></TABLE></TD>

               <TD background="widgets/gen_5.1.gif" style="background-repeat: repeat-y;"><img src="widgets/spacer.gif" height=1 width=4 alt=""></TD>

               <TD valign="top" width="100%"><!-- BOF: ./personal-templates/simple/businessnew/custom/style_l68.html -->

<TABLE WIDTH=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 VALIGN="top">

    <TR>

        <TD VALIGN="top">

    <TABLE DIR="LTR" WIDTH=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 bgcolor="#990000">

    <TR>

        <TD width="50" valign="top">

            <img src="widgets/gen_2.1.gif" border=0 width=50 height=20 alt=""></TD>

        <TD ALIGN="right" nowrap background="widgets/gen_1.1.gif" style="background-repeat: repeat-x;"><IMG SRC="widgets/gen_20.1.gif">&nbsp;</TD>

    </TR>

    </TABLE>

    <TABLE WIDTH=100% BORDER=0 CELLPADDING=1 CELLSPACING=0 bgcolor="#EFEEEE">

      <tr><td>

      <tr><td>

    <TABLE WIDTH=100% BORDER=0 CELLPADDING=0 CELLSPACING=5 bgcolor="#FFFFFF">

    <TR>

       <td>





<br />

<br />

<?php require("mid_inc_create_user.php"); ?>

</TD><TR>

</TABLE></TD></TR></TABLE>



</TD></TR></TABLE>











<!-- EOF: ./personal-templates/simple/businessnew/custom/style_l68.html -->



                                    </TD>

            </TR>

            <tr><td colspan="3" height="8" background="widgets/gen_6.1.gif" style="background-repeat: repeat-x;"><img src="widgets/spacer.gif" height=8 width=3 alt=""></td></tr>

            <TR>

               <TD colspan="3">

<center><table border="0" cellpadding="0" cellspacing="3"><tr><td align="center">



<br><font face="helvetica,verdana, arial" size="1">&nbsp;</font>



</td></tr></table></center>

<script language="javascript" src="widgets/noieactivate.js"></script>





<br>

<FONT FACE="verdana, arial, helvetica" SIZE="1">

<center>

<nobr>|<a href="index.php">Home</A>|</nobr>



<nobr>|Build Resume|</nobr>

</center>

</font>



<br></TD>

            </TR>

         </TABLE>

     </TD>

     <td background="widgets/gen_11.1.gif" style="background-repeat: repeat-y;background-position:left top;"><img src="widgets/spacer.gif" height=5 width=50 alt=""></td>

  </TR>

</TABLE>

<!-- EOF: ./personal-templates/simple/business/layout/l68.layout -->



    

  

   



<!-- BOF: ./personal-templates/simple/themes.show.body -->













<!-- EOF: ./personal-templates/simple/themes.show.body -->



</body>

<!-- BOF: ./personal-templates/simple/themes.show.end -->

















<!-- EOF: ./personal-templates/simple/themes.show.end -->





  



</html>







<!-- EOF: ./personal-templates/show.body -->











<!-- EOF: ./personal-templates/simple/personal/custom/custom.show.body -->



