<!--This file is part of the ReallyFreeResumeBuilder.com web application.

The ReallyFreeResumeBuilder.com is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.
-->
<?php

session_start();



if (isset($_GET['sign_out'])) {

	session_destroy();

	session_start();

}



//------------------------PHP automatically inserts escape characters.  Strip them -->

// courtesy of boutell.com



function stripslashes_nested($v)

{

  if (is_array($v)) {

    return array_map('stripslashes_nested', $v);

  } else {

    return stripslashes($v);

  }

}



if (get_magic_quotes_gpc()) {

  $_POST = stripslashes_nested($_POST);

}





//-----load post array into session array ------>

foreach ($_POST as $key => $i)

{

	$_SESSION[$key] = htmlentities($i);//convert HTML special characters, s.a. " in $i to escaped versions, e.g. &quot;

}



//------------set employer

if (!isset($_SESSION['number_employer']) || $_SESSION['number_employer'] < 1)

$_SESSION['number_employer'] = 1;





	//**************************************

	//**************************************ADD EMPLOYER HERE

	//**************************************

	if(!isset($_SESSION['last_employer_added']))

	$_SESSION['last_employer_add_or_sub'] = 0;

	

	if(!isset($_SESSION['last_employer_removed']))

	$_SESSION['last_employer_removed'] = 0;

	

	if(!isset($_SESSION['previous_number_employer']))

	$_SESSION['previous_number_employer'] = 0;

	





if (isset($_GET['add_employer_here']) && ($_SESSION['last_employer_added'] != $_GET['add_employer_here'] || $_SESSION['previous_number_employer'] != $_GET['number_employer'])) {



$to_add_employer_number_string = $_GET['add_employer_here'];

$to_add_employer_number = substr($to_add_employer_number_string, 8);

	//Then convert the string to an int

settype ($to_add_employer_number, "integer");



	$_SESSION['to_add_employer_number'] = $to_add_employer_number;

	for($i = $_SESSION['number_employer']; $i >= $to_add_employer_number;$i--) {

		

	$i_plus_one = $i + 1;

	$employer_name = "employer" . $i . "_name";

	$employer_plus_one_name = "employer" . $i_plus_one . "_name";	

	$_SESSION[$employer_plus_one_name] = $_SESSION[$employer_name];

		

	$employer_dates = "employer" . $i . "_dates";

	$employer_dates_plus = "employer" . $i_plus_one . "_dates";

	$_SESSION[$employer_dates_plus] = $_SESSION[$employer_dates];

	

	$employer_type = "employer" . $i . "_type";

	$employer_type_plus = "employer" . $i_plus_one . "_type";

	$_SESSION[$employer_type_plus] = $_SESSION[$employer_type];

	

	$employer_location = "employer" . $i . "_location";

	$employer_location_plus = "employer" . $i_plus_one . "_location";

	$_SESSION[$employer_location_plus] = $_SESSION[$employer_location];

	

	$job_title = "employer" . $i . "_job_title";

	$job_title_plus = "employer" . $i_plus_one . "_job_title";

	$_SESSION[$job_title_plus] = $_SESSION[$job_title];

	

	$employer_url = "employer" . $i . "_url";

	$employer_url_plus = "employer" . $i_plus_one . "_url";

	$_SESSION[$employer_url_plus] = $_SESSION[$employer_url];

	



	$number_accomplishments = "employer" . $i . "_number_accomplishments";

	$number_accomplishments_plus = "employer" . $i_plus_one . "_number_accomplishments";

	



	

		for($j = 1;$j <= $_SESSION[$number_accomplishments];$j++) {

			$employer_i_accomplishment_j = "employer" . $i . "_accomplishment" . $j;

			$employer_i_accomplishment_j_plus = "employer" . $i_plus_one . "_accomplishment" . $j;

			$_SESSION[$employer_i_accomplishment_j_plus] = $_SESSION[$employer_i_accomplishment_j];

			



			unset($_SESSION[$employer_i_accomplishment_j]);

			

		}



	

		$_SESSION[$number_accomplishments_plus] = $_SESSION[$number_accomplishments];

		$_SESSION[$number_accomplishments] = 1;

	}









delete_employer($to_add_employer_number);

$_SESSION['number_employer'] = $_SESSION['number_employer'] + 1;

}

	//END ADD EMPLOYER HERE









	//**************************************

	//**************************************REMOVE EMPLOYER HERE

	//**************************************

if(isset($_GET['remove_employer_here']) && ($_SESSION['last_employer_removed'] != $_GET['remove_employer_here'] || $_SESSION['previous_number_employer'] != $_GET['number_employer'])) {

	$to_remove_employer_number = $_GET['remove_employer_here'];

	settype ($to_remove_employer_number, "integer");

	

	//MOVE VALUES YOU DON'T WANT TO DELETE INTO AN ARRAY

	$storage = array("this" => "that");

	$to_remove_employer_number_plus = $to_remove_employer_number + 1;

	

	for($i = $to_remove_employer_number_plus; $i <= $_SESSION['number_employer']; $i++) {		

	//DON'T WORRY ABOUT NAMES OF VARIABLES: THEY WERE COPIED IN FROM ELSEWHERE

		$i_minus_one = $i - 1;

		$employer_name = "employer" . $i . "_name";

		$employer_minus_one_name = "employer" . $i_minus_one . "_name";	

		$storage[$employer_minus_one_name] = $_SESSION[$employer_name];

		

		$employer_dates = "employer" . $i . "_dates";

		$employer_dates_minus = "employer" . $i_minus_one . "_dates";

		$storage[$employer_dates_minus] = $_SESSION[$employer_dates];

	

		$employer_type = "employer" . $i . "_type";

		$employer_type_minus = "employer" . $i_minus_one . "_type";

		$storage[$employer_type_minus] = $_SESSION[$employer_type];

	

		$employer_location = "employer" . $i . "_location";

		$employer_location_minus = "employer" . $i_minus_one . "_location";

		$storage[$employer_location_minus] = $_SESSION[$employer_location];

	

		$job_title = "employer" . $i . "_job_title";

		$job_title_minus = "employer" . $i_minus_one . "_job_title";

		$storage[$job_title_minus] = $_SESSION[$job_title];

	

		$employer_url = "employer" . $i . "_url";

		$employer_url_minus = "employer" . $i_minus_one . "_url";

		$storage[$employer_url_minus] = $_SESSION[$employer_url];

	





		$number_accomplishments = "employer" . $i . "_number_accomplishments";

		$number_accomplishments_minus = "employer" . $i_minus_one . "_number_accomplishments";

		$storage[$number_accomplishments_minus] = $_SESSION[$number_accomplishments];

	

		for($j = 1;$j <= $_SESSION[$number_accomplishments];$j++) {

			$employer_i_accomplishment_j = "employer" . $i . "_accomplishment" . $j;

			$employer_i_accomplishment_j_minus = "employer" . $i_minus_one . "_accomplishment" . $j;

			$storage[$employer_i_accomplishment_j_minus] = $_SESSION[$employer_i_accomplishment_j];

		}

		

	}

//Now delete the employers.



	for($i = $to_remove_employer_number;$i <= $_SESSION['number_employer'];$i++) {

		delete_employer($i);

	}



//Now copy the values back in.



	foreach($storage as $key => $value) {

		$_SESSION[$key] = $value;

		unset($storage[$key]);

	}

	

	

 

$_SESSION['number_employer'] = $_SESSION['number_employer'] - 1;

}









function delete_employer($employer_number)

{



	

$employer_name = "employer" . $employer_number . "_name";

$employer_dates = "employer" . $employer_number . "_dates";

$employer_type = "employer" . $employer_number . "_type";

$employer_location = "employer" . $employer_number . "_location";

$employer_job_title = "employer" . $employer_number . "_job_title";

$employer_url = "employer" . $employer_number . "_url";



unset($_SESSION[$employer_name]);

unset($_SESSION[$employer_dates]);

unset($_SESSION[$employer_type]);

unset($_SESSION[$employer_location]);

unset($_SESSION[$employer_job_title]);

unset($_SESSION[$employer_url]);



		

$number_accomplishments = "employer" . $employer_number . "_number_accomplishments";

	

    for($j =1; $j <= $_SESSION[$number_accomplishments]; $j++) {

	

		$employer_i_accomplishment_j = "employer" . $employer_number . "_accomplishment$j";

    	unset($_SESSION[$employer_i_accomplishment_j]);

	

	}

$_SESSION[$number_accomplishments] = 1;

}



if(isset($_GET['add_employer_here']))

$_SESSION['last_employer_added'] = $_GET['add_employer_here'];



if(isset($_GET['remove_employer_here']))

$_SESSION['last_employer_removed'] = $_GET['remove_employer_here'];



if(isset($_GET['number_employer']))

$_SESSION['previous_number_employer'] = $_GET['number_employer'];





//----------reset # employer



if ($_SESSION['number_employer'] < 1)

$_SESSION['number_employer'] = 1;





if(!isset($_SESSION['previous_number_skills']))

$_SESSION['previous_number_skills'] = 0;



//----------set skills

if (!isset($_SESSION['number_skills']) || $_SESSION['number_skills'] < 1)

$_SESSION['number_skills'] = 1;







if (isset($_GET['add_skill'])) {

	$number_skill_add = $_GET['add_skill'];

	settype($number_skill_add, integer);

	

	if($_SESSION['number_skills'] == $number_skill_add -1)

	$_SESSION['number_skills'] = $_SESSION['number_skills'] + 1;

}



if (isset($_GET['remove_skill']) && $_SESSION['number_skills'] >=1) {

	$number_skill_remove = $_GET['remove_skill'];

	settype($number_skill_remove, integer);

	

	if($_SESSION['number_skills'] == $number_skill_remove +1)

	$_SESSION['number_skills'] = $_SESSION['number_skills'] - 1;



}









//-----------set education

if (!isset($_SESSION['number_education']) || $_SESSION['number_education'] < 1)

$_SESSION['number_education'] = 1;



if (isset($_GET['add_education'])) {

	$number_education_add = $_GET['add_education'];

	settype($number_education_add, integer);

	

	if($_SESSION['number_education'] == $number_education_add -1)

	$_SESSION['number_education'] = $_SESSION['number_education'] + 1;

}



if (isset($_GET['remove_education']) && $_SESSION['number_education'] >=1) {

	$number_education_remove = $_GET['remove_education'];

	settype($number_education_remove, integer);

	

	if($_SESSION['number_education'] == $number_education_remove +1)

	$_SESSION['number_education'] = $_SESSION['number_education'] - 1;



}





//-----------set interests

if (!isset($_SESSION['number_interest']) || $_SESSION['number_interest'] < 1)

$_SESSION['number_interest'] = 1;



if (isset($_GET['add_interest'])) {

	$number_interest_add = $_GET['add_interest'];

	settype($number_interest_add, integer);

	

	if($_SESSION['number_interest'] == $number_interest_add -1)

	$_SESSION['number_interest'] = $_SESSION['number_interest'] + 1;

}



if (isset($_GET['remove_interest']) && $_SESSION['number_interest'] >=1) {

	$number_interest_remove = $_GET['remove_interest'];

	settype($number_interest_remove, integer);

	

	if($_SESSION['number_interest'] == $number_interest_remove +1)

	$_SESSION['number_interest'] = $_SESSION['number_interest'] - 1;

}







//$con -= mysql_connect("localhost", "bdeans10_GO108", "jfitzgerald");

//$con -= mysql_connect("localhost", "root", "");

require("database_access.php");



//mysql_select_db("bdeans10_users",$con);



//-------------check if logged in, check password and save $_SESSION array  ------------->

if (isset($_SESSION['logged_in'])) {



    if (!isset($_SESSION['password']))

	die ("No password set");







$query = "SELECT info FROM users WHERE screen_name='" . $_SESSION['screen_name'] . "'";



if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }



    

//OLD $result = mysql_query($query);



$result = $mysqli->use_result();

    

$file_user_contents = "";



    while ($i = $result->fetch_assoc()) {

        $file_user_contents = $i['info'];;

    }

    

    /* OLD

	while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

	$file_user_contents = $i['info'];

	}

    */



	$the_file_contents_array = array();

	$fc_array = explode (";;;", $file_user_contents);

	  foreach ($fc_array as $i) {

    	$key_value_pair = explode ("===", $i);

        

		/*if the $key_value_pair2[1] is not set, that means we're at the end of screen_name.txt, so we can break the loop */

		if (!isset($key_value_pair[1]))

		break;

		

		$key = $key_value_pair[0];

        $value = $key_value_pair[1];

        $the_file_contents_array[$key] = $value;

    	}    

        



    $password = $_SESSION['password'];

    if ($password != $the_file_contents_array['password1'])

    die("Wrong password");





	//------------if logged in, save session data -------->

	$screen_name = $_SESSION['screen_name'];

	$string_save = "";

	foreach ($_SESSION as $key => $i) {

	$i = html_entity_decode($i);  //if any HTML entities are set (such as &quot;), converts back to "

	$string_save .= $key . "===" . $i . ";;;";

	}

	

	$last_updated = mktime();

	$string_save = mysql_real_escape_string($string_save);

	$query = "UPDATE users SET session='$string_save', last_updated='$last_updated' WHERE screen_name='$screen_name'";

	//OLD mysql_query($query) or die(mysql_error() . "<br /><br />String_save=$string_save");

    

    if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }

    

}





//UPDATE MAKE_PROFILE_PUBLIC

if (isset($_SESSION['screen_name'])) {

		$query = "SELECT make_profile_public FROM users WHERE screen_name='$screen_name'";

		//OLD $result = mysql_query($query);

    

        if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }

    

        $result = $mysqli->use_result();

    

        while ($row = $result->fetch_assoc()) {

            echo " screen_name = " . $row['screen_name'] . "\n";

        }

    

		$make_profile_public = 0;

			//OLD while ($i = mysql_fetch_array($result, MYSQL_ASSOC)) {

            while ($i = $res->fetch_assoc()) {

            

			$make_profile_public = $i['make_profile_public'];

			}

	$_SESSION['make_profile_public'] = $make_profile_public;

	

	

	if (!isset($_POST['make_profile_public']) && $make_profile_public == 1 && isset($_POST['coming_from']) && $_POST['coming_from'] == "build_resume") {

	//turn off make_profile_public

		$query = "UPDATE users SET make_profile_public=0 WHERE screen_name='$screen_name'";

		

        /* OLD mysql_query($query) 

		or die(mysql_error()); */

        if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }

        

		$_SESSION['make_profile_public'] = 0;  

	}

	

	if (isset($_POST['make_profile_public']) && $make_profile_public == 0) {

	//turn on make_profile_public

		$query = "UPDATE users SET make_profile_public=1 WHERE screen_name='$screen_name'";

		

        if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }

        /* mysql_query($query) 

		or die(mysql_error()); */ 

		$_SESSION['make_profile_public'] = 1; 

	}

}

else{

//-------------------------------------------->

//-------------------------------------------->if user not signed in, update the stored_sessions table

//-------------------------------------------->



	$string_save = "";

	

	foreach ($_SESSION as $key => $i) {

	$i = html_entity_decode($i);  //if any HTML entities are set (such as &quot;), converts back to "

	$string_save .= $key . "===" . $i . ";;;";

	}

	$string_save = mysql_real_escape_string($string_save);



	$date_added = date("d-m-Y");

	$last_updated = mktime();

	

	if (isset($_SESSION['stored_sessions_id_set'])) {

		$session_id = $_SESSION['stored_sessions_id_set'];

		$query = "UPDATE stored_sessions SET session_data='$string_save', last_updated='$last_updated' WHERE session_id='$session_id'";

		//OLD mysql_query($query) or die(mysql_error());

        

        if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }

        

	}

	else {	//time to set 'stored_sessions_id_set'

			//check, just to be sure, that that session id and date combination aren't already in use (yes, this was a problem)

		$session_id =  $date_added . session_id();

		$query = "SELECT id FROM stored_sessions WHERE session_id='$session_id'";

		//OLD $result = mysql_query($query) or die(mysql_error());	

		

        if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }

        $result = $mysqli->use_result();

        //What does mysqli->use_result() return compared to the old mysql_query? 23Apr2018

        

        if ($result != "") {

			session_regenerate_id();

			$session_id = $date_added . session_id();

		}



                $break = 0;

		if(isset($_POST['name']) && ($_POST['name'] == "" || $_POST['address_line_1'] == "" || $_POST['address_line_2'] == "" || $_POST['email'] == "" || $_POST['phone'] == "" || $_POST['education1'] == ""))

		$break = 1;

		

		if(!$break) {		

		$query = "INSERT INTO stored_sessions (date_added, session_id, session_data, last_updated) VALUES ('$date_added', '$session_id', '$string_save', '$last_updated')";

		//OLD mysql_query($query) or die(mysql_error());	

        if (!$mysqli->query($query))

        {

            printf("Errormessage: %s\n", $mysqli->error);

        }    

        

		$_SESSION['stored_sessions_id_set'] = $session_id;

		}

	}

}

?>
